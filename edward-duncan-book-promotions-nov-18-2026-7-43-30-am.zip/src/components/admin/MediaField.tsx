import { Image as ImageIcon, Upload, X } from 'lucide-react';
import React, { useState } from 'react';
import type { MediaAsset, MediaAssetType } from '../../types/cms';
import { adminFetch } from '../../utils/adminAuth';
import { ResilientImage } from '../ResilientImage';

interface MediaFieldProps {
  label: string;
  value: string;
  onChange: (nextUrl: string) => void;
  assetType?: MediaAssetType;
  accept?: string;
  mediaLibrary: MediaAsset[];
  onMediaUploaded: (asset: MediaAsset) => void;
  placeholder?: string;
}

export function MediaField({
  label,
  value,
  onChange,
  assetType = 'general',
  accept = 'image/jpeg,image/png,image/webp,image/gif',
  mediaLibrary,
  onMediaUploaded,
  placeholder = '/uploads/... or https://...',
}: MediaFieldProps) {
  const [uploading, setUploading] = useState(false);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setUploadError(null);
    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('assetType', assetType);
      formData.append('title', file.name);
      const res = await adminFetch('/api/admin/upload', {
        method: 'POST',
        body: formData,
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Upload failed.');
      }
      onMediaUploaded(data.asset);
      onChange(data.asset.url);
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'Upload failed.');
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const isVideoAccept = accept.includes('video');

  return (
    <div className="space-y-2">
      <label className="block text-xs font-semibold text-slate-700">{label}</label>
      <div className="flex flex-wrap items-center gap-2">
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className="flex-1 min-w-[200px] px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#C59B27]"
        />
        <label className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-300 bg-white text-xs font-semibold text-[#0B192C] hover:bg-slate-50 cursor-pointer whitespace-nowrap">
          <Upload className="w-3.5 h-3.5 text-[#8F6A10]" />
          <span>{uploading ? 'Uploading...' : 'Upload'}</span>
          <input type="file" accept={accept} onChange={handleFileChange} className="sr-only" />
        </label>
        <button
          type="button"
          onClick={() => setPickerOpen(true)}
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-300 bg-slate-50 text-xs font-semibold text-[#0B192C] hover:bg-slate-100 whitespace-nowrap"
        >
          <ImageIcon className="w-3.5 h-3.5 text-[#8F6A10]" />
          <span>Library</span>
        </button>
      </div>

      {uploadError && <p className="text-xs text-red-600">{uploadError}</p>}

      {value && !isVideoAccept && (
        <div className="w-28 h-20 rounded-lg overflow-hidden border border-slate-200 bg-slate-100">
          <ResilientImage src={value} alt={label} className="w-full h-full object-cover" />
        </div>
      )}

      {pickerOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4"
          onClick={() => setPickerOpen(false)}
        >
          <div
            className="bg-white rounded-2xl max-w-3xl w-full border border-slate-200 overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
              <h4 className="font-display text-lg font-semibold text-[#0B192C]">
                Select from Media Library
              </h4>
              <button
                type="button"
                onClick={() => setPickerOpen(false)}
                className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-6 max-h-[65vh] overflow-y-auto grid grid-cols-2 sm:grid-cols-3 gap-4">
              {mediaLibrary.map((asset) => {
                const isVideo = asset.mimeType.startsWith('video/');
                return (
                  <button
                    key={asset.id}
                    type="button"
                    onClick={() => {
                      onChange(asset.url);
                      setPickerOpen(false);
                    }}
                    className="group border border-slate-200 rounded-xl overflow-hidden text-left hover:border-[#C59B27] transition-colors"
                  >
                    <div className="aspect-[4/3] bg-slate-100 overflow-hidden flex items-center justify-center">
                      {isVideo ? (
                        <div className="text-xs font-semibold text-[#0B192C] p-3 text-center">
                          Video File · {asset.originalName}
                        </div>
                      ) : (
                        <ResilientImage
                          src={asset.url}
                          alt={asset.title}
                          className="w-full h-full object-cover"
                        />
                      )}
                    </div>
                    <div className="p-2.5">
                      <p className="text-xs font-medium text-[#0B192C] truncate">{asset.title}</p>
                      <p className="text-[11px] text-slate-500 truncate">{asset.assetType}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
