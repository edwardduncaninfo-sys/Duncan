import { ArrowRight, Film, Image as ImageIcon, Plus, Sparkles, Trash2, Upload } from 'lucide-react';
import React, { useState } from 'react';
import type {
  AboutContent,
  ContactSubmission,
  HomepageContent,
  MediaAsset,
  PagesCopyContent,
  PortfolioCategory,
  PortfolioItem,
  WebsiteSettings,
} from '../../types/cms';
import { adminFetch } from '../../utils/adminAuth';
import { MediaField } from './MediaField';

interface OverviewProps {
  stats: {
    services: number;
    portfolio: number;
    featuredBooks: number;
    authors: number;
    testimonials: number;
    submissions: number;
    newSubmissions: number;
    media: number;
  };
  recentSubmissions: ContactSubmission[];
  onNavigate: (tab: string) => void;
}

export function AdminOverviewPanel({ stats, recentSubmissions, onNavigate }: OverviewProps) {
  const kpis = [
    { label: 'Active Services', value: stats.services, tab: 'services' },
    { label: 'Portfolio Projects', value: stats.portfolio, tab: 'portfolio' },
    { label: 'Featured Books', value: stats.featuredBooks, tab: 'books' },
    { label: 'Authors Directory', value: stats.authors, tab: 'authors' },
    { label: 'Total Inquiries', value: stats.submissions, tab: 'submissions' },
    { label: 'New Inquiries', value: stats.newSubmissions, tab: 'submissions' },
    { label: 'Testimonials', value: stats.testimonials, tab: 'testimonials' },
    { label: 'Media Assets', value: stats.media, tab: 'media' },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h2 className="font-display text-2xl font-semibold text-[#0B192C]">Dashboard Overview</h2>
        <p className="text-sm text-slate-600 mt-1">
          Manage all public website pages, promotional uploads, and client inquiries from one private workspace.
        </p>
      </div>

      {/* Tabular KPI Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {kpis.map((item) => (
          <button
            key={item.label}
            type="button"
            onClick={() => onNavigate(item.tab)}
            className="bg-white border border-slate-200 rounded-xl p-5 text-left hover:border-[#C59B27] transition-colors"
          >
            <p className="text-xs font-medium text-slate-500">{item.label}</p>
            <p className="font-mono-tabular text-2xl font-semibold text-[#0B192C] mt-2">
              {item.value}
            </p>
          </button>
        ))}
      </div>

      {/* Promotional Upload Center Quick Launch */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-display text-lg font-semibold text-[#0B192C]">
              Promotional Upload Center
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Quickly publish new spotlights, banners, or video book trailers directly to your portfolio.
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button
            type="button"
            onClick={() => onNavigate('upload-spotlight')}
            className="flex items-center justify-between p-4 rounded-xl border border-slate-200 hover:border-[#C59B27] bg-[#F8F9FB] text-left transition-colors"
          >
            <div className="flex items-center gap-3">
              <Sparkles className="w-5 h-5 text-[#8F6A10]" />
              <div>
                <p className="text-sm font-semibold text-[#0B192C]">Upload Author Spotlight</p>
                <p className="text-xs text-slate-500">Author photo, cover & profile</p>
              </div>
            </div>
            <ArrowRight className="w-4 h-4 text-slate-400" />
          </button>

          <button
            type="button"
            onClick={() => onNavigate('upload-banners')}
            className="flex items-center justify-between p-4 rounded-xl border border-slate-200 hover:border-[#C59B27] bg-[#F8F9FB] text-left transition-colors"
          >
            <div className="flex items-center gap-3">
              <ImageIcon className="w-5 h-5 text-[#8F6A10]" />
              <div>
                <p className="text-sm font-semibold text-[#0B192C]">Upload Promotional Banners</p>
                <p className="text-xs text-slate-500">Custom banner graphics</p>
              </div>
            </div>
            <ArrowRight className="w-4 h-4 text-slate-400" />
          </button>

          <button
            type="button"
            onClick={() => onNavigate('upload-trailers')}
            className="flex items-center justify-between p-4 rounded-xl border border-slate-200 hover:border-[#C59B27] bg-[#F8F9FB] text-left transition-colors"
          >
            <div className="flex items-center gap-3">
              <Film className="w-5 h-5 text-[#8F6A10]" />
              <div>
                <p className="text-sm font-semibold text-[#0B192C]">Upload Book Trailers</p>
                <p className="text-xs text-slate-500">MP4/WebM video or link</p>
              </div>
            </div>
            <ArrowRight className="w-4 h-4 text-slate-400" />
          </button>
        </div>
      </div>

      {/* Latest Contact Inquiries */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <h3 className="font-display text-lg font-semibold text-[#0B192C]">
            Recent Promotion Inquiries
          </h3>
          <button
            type="button"
            onClick={() => onNavigate('submissions')}
            className="text-xs font-semibold text-[#8F6A10] hover:underline"
          >
            View All Submissions
          </button>
        </div>
        {recentSubmissions.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500">
            No promotion requests received yet. Inquiries submitted via the public Contact page will appear here.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 border-b border-slate-200 text-xs text-slate-500">
                <tr>
                  <th className="py-3 px-4 font-semibold">Author</th>
                  <th className="py-3 px-4 font-semibold">Book Title</th>
                  <th className="py-3 px-4 font-semibold">Requested Service</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-4 font-semibold text-right">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {recentSubmissions.slice(0, 5).map((sub) => (
                  <tr key={sub.id} className="hover:bg-slate-50">
                    <td className="py-3 px-4 font-medium text-[#0B192C]">{sub.fullName}</td>
                    <td className="py-3 px-4 text-slate-600">{sub.bookTitle}</td>
                    <td className="py-3 px-4 text-slate-600">{sub.requestedService}</td>
                    <td className="py-3 px-4 text-xs font-semibold text-[#8F6A10]">{sub.status}</td>
                    <td className="py-3 px-4 text-right font-mono-tabular text-xs text-slate-500">
                      {sub.createdAt.slice(0, 10)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

interface UploadCenterProps {
  mode: 'spotlight' | 'banner' | 'trailer';
  mediaLibrary: MediaAsset[];
  onMediaUploaded: (asset: MediaAsset) => void;
  onPortfolioCreated: (item: PortfolioItem) => void;
  onNotify: (msg: string, isError?: boolean) => void;
}

export function PromotionalUploadCenterPanel({
  mode,
  mediaLibrary,
  onMediaUploaded,
  onPortfolioCreated,
  onNotify,
}: UploadCenterProps) {
  const defaultCategory: PortfolioCategory =
    mode === 'spotlight'
      ? 'Author Spotlight Features'
      : mode === 'banner'
        ? 'Promotional Banners'
        : 'Book Trailers';

  const heading =
    mode === 'spotlight'
      ? 'Upload Author Spotlight'
      : mode === 'banner'
        ? 'Upload Promotional Banners'
        : 'Upload Book Trailers';

  const subtitle =
    mode === 'spotlight'
      ? 'Upload author photography, book covers, and editorial spotlight notes directly into the portfolio.'
      : mode === 'banner'
        ? 'Upload high-resolution custom promotional banner graphics and publish them to your showcase.'
        : 'Upload trailer video files (MP4, WebM, MOV) or attach a YouTube/Vimeo trailer link with cover artwork.';

  const [projectTitle, setProjectTitle] = useState('');
  const [authorName, setAuthorName] = useState('');
  const [bookTitle, setBookTitle] = useState('');
  const [bookCoverUrl, setBookCoverUrl] = useState('');
  const [bannerImageUrl, setBannerImageUrl] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [publicationDate, setPublicationDate] = useState(new Date().toISOString().slice(0, 10));
  const [description, setDescription] = useState('');
  const [featuredOnHome, setFeaturedOnHome] = useState(true);
  const [saving, setSaving] = useState(false);

  const handlePublish = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!projectTitle.trim() || !bookTitle.trim()) {
      onNotify('Project Title and Book Title are required.', true);
      return;
    }
    setSaving(true);
    try {
      const res = await adminFetch('/api/admin/portfolio', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          projectTitle: projectTitle.trim(),
          authorName: authorName.trim(),
          bookTitle: bookTitle.trim(),
          bookCoverUrl: bookCoverUrl.trim(),
          bannerImageUrl: bannerImageUrl.trim(),
          videoUrl: videoUrl.trim(),
          videoType: videoUrl.trim() ? (videoUrl.startsWith('/uploads/') ? 'upload' : 'external') : 'none',
          description: description.trim(),
          category: defaultCategory,
          publicationDate,
          featuredOnHome,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to publish item.');

      onPortfolioCreated(data.item);
      setProjectTitle('');
      setAuthorName('');
      setBookTitle('');
      setBookCoverUrl('');
      setBannerImageUrl('');
      setVideoUrl('');
      setDescription('');
      onNotify(`${heading} published to portfolio successfully.`);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Failed to publish.', true);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h2 className="font-display text-2xl font-semibold text-[#0B192C]">{heading}</h2>
        <p className="text-sm text-slate-600 mt-1">{subtitle}</p>
      </div>

      <form
        onSubmit={handlePublish}
        className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-6"
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Project Title *
            </label>
            <input
              type="text"
              required
              value={projectTitle}
              onChange={(e) => setProjectTitle(e.target.value)}
              placeholder={
                mode === 'spotlight'
                  ? 'e.g., Author Spotlight: Elena Vance'
                  : mode === 'banner'
                    ? 'e.g., Launch Banner Suite: Midnight Harbor'
                    : 'e.g., Official Book Trailer: Midnight Harbor'
              }
              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Portfolio Category
            </label>
            <input
              type="text"
              readOnly
              value={defaultCategory}
              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-slate-50 text-sm text-slate-600"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Author Name
            </label>
            <input
              type="text"
              value={authorName}
              onChange={(e) => setAuthorName(e.target.value)}
              placeholder="Author full name"
              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Book Title *
            </label>
            <input
              type="text"
              required
              value={bookTitle}
              onChange={(e) => setBookTitle(e.target.value)}
              placeholder="Featured book title"
              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Publication Date
            </label>
            <input
              type="date"
              value={publicationDate}
              onChange={(e) => setPublicationDate(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-sm font-mono-tabular"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <MediaField
            label={mode === 'spotlight' ? 'Author Photo or Book Cover' : 'Book Cover Image'}
            value={bookCoverUrl}
            onChange={setBookCoverUrl}
            assetType={mode === 'spotlight' ? 'author_photo' : 'book_cover'}
            mediaLibrary={mediaLibrary}
            onMediaUploaded={onMediaUploaded}
          />

          <MediaField
            label={mode === 'banner' ? 'Promotional Banner Graphic *' : 'Promotional Banner / Poster Image'}
            value={bannerImageUrl}
            onChange={setBannerImageUrl}
            assetType="banner"
            mediaLibrary={mediaLibrary}
            onMediaUploaded={onMediaUploaded}
          />
        </div>

        {mode === 'trailer' && (
          <MediaField
            label="Trailer Video File (MP4, WebM, MOV) or YouTube/Vimeo Link"
            value={videoUrl}
            onChange={setVideoUrl}
            assetType="video_trailer"
            accept="video/mp4,video/webm,video/quicktime"
            mediaLibrary={mediaLibrary}
            onMediaUploaded={onMediaUploaded}
            placeholder="/uploads/trailer.mp4 or https://youtube.com/watch?v=..."
          />
        )}

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1.5">
            Project Description & Campaign Notes
          </label>
          <textarea
            rows={4}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe the promotional spotlight, visual direction, or trailer narrative..."
            className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-sm"
          />
        </div>

        <label className="inline-flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
          <input
            type="checkbox"
            checked={featuredOnHome}
            onChange={(e) => setFeaturedOnHome(e.target.checked)}
            className="rounded border-slate-300 text-[#0B192C]"
          />
          <span>Highlight in Homepage Promotional Showcase</span>
        </label>

        <div className="pt-2">
          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-[#0B192C] text-white text-sm font-semibold hover:bg-[#132945] disabled:opacity-60"
          >
            <Upload className="w-4 h-4 text-[#D9B44A]" />
            <span>{saving ? 'Publishing...' : `Publish to ${defaultCategory}`}</span>
          </button>
        </div>
      </form>
    </div>
  );
}

interface ManageHomepageProps {
  homepage: HomepageContent;
  mediaLibrary: MediaAsset[];
  onMediaUploaded: (asset: MediaAsset) => void;
  onSaved: (updated: HomepageContent) => void;
  onNotify: (msg: string, isError?: boolean) => void;
}

export function ManageHomepagePanel({
  homepage,
  mediaLibrary,
  onMediaUploaded,
  onSaved,
  onNotify,
}: ManageHomepageProps) {
  const [form, setForm] = useState<HomepageContent>(homepage);
  const [saving, setSaving] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await adminFetch('/api/admin/homepage', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Save failed.');
      onSaved(data.homepage);
      onNotify('Homepage content saved and published.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Save failed.', true);
    } finally {
      setSaving(false);
    }
  };

  const pillars = form.introPillars || [];

  return (
    <form onSubmit={handleSave} className="space-y-6 max-w-4xl">
      <div>
        <h2 className="font-display text-2xl font-semibold text-[#0B192C]">Manage Homepage</h2>
        <p className="text-sm text-slate-600 mt-1">
          Edit every kicker, headline, subheadline, pillar card, CTA label, and visual image displayed on the Homepage.
        </p>
      </div>

      {/* Hero Section */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <h3 className="font-display text-lg font-semibold text-[#0B192C]">1. Hero Section</h3>
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Hero Kicker Line</label>
          <input
            type="text"
            value={form.heroKicker}
            onChange={(e) => setForm({ ...form, heroKicker: e.target.value })}
            className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
          />
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Hero Headline</label>
          <input
            type="text"
            value={form.heroHeadline}
            onChange={(e) => setForm({ ...form, heroHeadline: e.target.value })}
            className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
          />
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Hero Supporting Text</label>
          <textarea
            rows={3}
            value={form.heroSubheadline}
            onChange={(e) => setForm({ ...form, heroSubheadline: e.target.value })}
            className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
          />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Primary CTA Label</label>
            <input
              type="text"
              value={form.primaryCtaLabel}
              onChange={(e) => setForm({ ...form, primaryCtaLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Secondary CTA Label</label>
            <input
              type="text"
              value={form.secondaryCtaLabel}
              onChange={(e) => setForm({ ...form, secondaryCtaLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
        </div>
        <MediaField
          label="Hero Background Image"
          value={form.heroImageUrl}
          onChange={(url) => setForm({ ...form, heroImageUrl: url })}
          assetType="banner"
          mediaLibrary={mediaLibrary}
          onMediaUploaded={onMediaUploaded}
        />
      </div>

      {/* Promotional Showcase Section */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
        <h3 className="font-display text-lg font-semibold text-[#0B192C]">2. Promotional Showcase Section</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Showcase Kicker</label>
            <input
              type="text"
              value={form.showcaseKicker}
              onChange={(e) => setForm({ ...form, showcaseKicker: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Showcase Link Label</label>
            <input
              type="text"
              value={form.showcaseCtaLabel}
              onChange={(e) => setForm({ ...form, showcaseCtaLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Showcase Heading</label>
          <input
            type="text"
            value={form.showcaseHeading}
            onChange={(e) => setForm({ ...form, showcaseHeading: e.target.value })}
            className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
          />
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Showcase Subheading</label>
          <textarea
            rows={2}
            value={form.showcaseSubheading}
            onChange={(e) => setForm({ ...form, showcaseSubheading: e.target.value })}
            className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
          />
        </div>
      </div>

      {/* Specialist Introduction */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <h3 className="font-display text-lg font-semibold text-[#0B192C]">3. Specialist Introduction</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Intro Kicker</label>
            <input
              type="text"
              value={form.introKicker}
              onChange={(e) => setForm({ ...form, introKicker: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Intro Button Label</label>
            <input
              type="text"
              value={form.introCtaLabel}
              onChange={(e) => setForm({ ...form, introCtaLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Intro Heading</label>
          <input
            type="text"
            value={form.introHeading}
            onChange={(e) => setForm({ ...form, introHeading: e.target.value })}
            className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
          />
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Intro Body Copy</label>
          <textarea
            rows={4}
            value={form.introBody}
            onChange={(e) => setForm({ ...form, introBody: e.target.value })}
            className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
          />
        </div>

        {/* Intro Pillars */}
        <div className="space-y-3 pt-2 border-t border-slate-100">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold text-slate-700">Intro Highlight Pillars</label>
            <button
              type="button"
              onClick={() =>
                setForm({
                  ...form,
                  introPillars: [...pillars, { title: 'New Pillar', subtitle: 'Supporting detail' }],
                })
              }
              className="inline-flex items-center gap-1 text-xs font-semibold text-[#8F6A10] hover:underline"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Pillar</span>
            </button>
          </div>
          <div className="space-y-3">
            {pillars.map((pillar, idx) => (
              <div key={idx} className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center bg-[#F8F9FB] p-3 rounded-lg border border-slate-200">
                <input
                  type="text"
                  value={pillar.title}
                  placeholder="Pillar title"
                  onChange={(e) => {
                    const next = [...pillars];
                    next[idx] = { ...next[idx], title: e.target.value };
                    setForm({ ...form, introPillars: next });
                  }}
                  className="sm:col-span-5 px-3 py-2 rounded-lg border border-slate-300 bg-white text-sm"
                />
                <input
                  type="text"
                  value={pillar.subtitle}
                  placeholder="Pillar subtitle"
                  onChange={(e) => {
                    const next = [...pillars];
                    next[idx] = { ...next[idx], subtitle: e.target.value };
                    setForm({ ...form, introPillars: next });
                  }}
                  className="sm:col-span-6 px-3 py-2 rounded-lg border border-slate-300 bg-white text-sm"
                />
                <button
                  type="button"
                  aria-label="Remove pillar"
                  onClick={() =>
                    setForm({
                      ...form,
                      introPillars: pillars.filter((_, i) => i !== idx),
                    })
                  }
                  className="sm:col-span-1 p-2 text-red-600 hover:bg-red-50 rounded-lg justify-self-end"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>

        <MediaField
          label="Specialist Portrait Image"
          value={form.introPortraitUrl}
          onChange={(url) => setForm({ ...form, introPortraitUrl: url })}
          assetType="author_photo"
          mediaLibrary={mediaLibrary}
          onMediaUploaded={onMediaUploaded}
        />
      </div>

      {/* Services, Featured Books & Testimonials Section Headings */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <h3 className="font-display text-lg font-semibold text-[#0B192C]">4. Services, Featured Books & Testimonials Sections</h3>

        <div className="space-y-3 pb-4 border-b border-slate-100">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Services Kicker</label>
              <input
                type="text"
                value={form.servicesKicker}
                onChange={(e) => setForm({ ...form, servicesKicker: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Services Link Label</label>
              <input
                type="text"
                value={form.servicesCtaLabel}
                onChange={(e) => setForm({ ...form, servicesCtaLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Services Heading</label>
            <input
              type="text"
              value={form.servicesHeading}
              onChange={(e) => setForm({ ...form, servicesHeading: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Services Subheading</label>
            <textarea
              rows={2}
              value={form.servicesSubheading}
              onChange={(e) => setForm({ ...form, servicesSubheading: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
        </div>

        <div className="space-y-3 pb-4 border-b border-slate-100">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Featured Books Kicker</label>
              <input
                type="text"
                value={form.successStoriesKicker}
                onChange={(e) => setForm({ ...form, successStoriesKicker: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Featured Books Link Label</label>
              <input
                type="text"
                value={form.successStoriesCtaLabel}
                onChange={(e) => setForm({ ...form, successStoriesCtaLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Featured Books Heading</label>
            <input
              type="text"
              value={form.successStoriesHeading}
              onChange={(e) => setForm({ ...form, successStoriesHeading: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Featured Books Subheading</label>
            <textarea
              rows={2}
              value={form.successStoriesSubheading}
              onChange={(e) => setForm({ ...form, successStoriesSubheading: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
        </div>

        <div className="space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Testimonials Kicker</label>
              <input
                type="text"
                value={form.testimonialsKicker}
                onChange={(e) => setForm({ ...form, testimonialsKicker: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Testimonials Heading</label>
              <input
                type="text"
                value={form.testimonialsHeading}
                onChange={(e) => setForm({ ...form, testimonialsHeading: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Testimonials Subheading</label>
            <textarea
              rows={2}
              value={form.testimonialsSubheading}
              onChange={(e) => setForm({ ...form, testimonialsSubheading: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
        </div>
      </div>

      {/* Bottom Call-To-Action */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
        <h3 className="font-display text-lg font-semibold text-[#0B192C]">5. Bottom Call-to-Action</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Bottom CTA Kicker</label>
            <input
              type="text"
              value={form.ctaKicker}
              onChange={(e) => setForm({ ...form, ctaKicker: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Bottom CTA Button Label</label>
            <input
              type="text"
              value={form.ctaButtonLabel}
              onChange={(e) => setForm({ ...form, ctaButtonLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Bottom CTA Heading</label>
          <input
            type="text"
            value={form.ctaHeading}
            onChange={(e) => setForm({ ...form, ctaHeading: e.target.value })}
            className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
          />
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Bottom CTA Supporting Copy</label>
          <textarea
            rows={2}
            value={form.ctaBody}
            onChange={(e) => setForm({ ...form, ctaBody: e.target.value })}
            className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
          />
        </div>
      </div>

      <button
        type="submit"
        disabled={saving}
        className="px-6 py-3 rounded-lg bg-[#0B192C] text-white text-sm font-semibold hover:bg-[#132945] disabled:opacity-60"
      >
        {saving ? 'Saving Changes...' : 'Save Homepage Changes'}
      </button>
    </form>
  );
}

interface ManageAboutProps {
  about: AboutContent;
  mediaLibrary: MediaAsset[];
  onMediaUploaded: (asset: MediaAsset) => void;
  onSaved: (updated: AboutContent) => void;
  onNotify: (msg: string, isError?: boolean) => void;
}

export function ManageAboutPanel({
  about,
  mediaLibrary,
  onMediaUploaded,
  onSaved,
  onNotify,
}: ManageAboutProps) {
  const [form, setForm] = useState<AboutContent>(about);
  const [bioText, setBioText] = useState(about.biography.join('\n\n'));
  const [saving, setSaving] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload: AboutContent = {
        ...form,
        biography: bioText
          .split(/\n{2,}/)
          .map((p) => p.trim())
          .filter(Boolean),
      };
      const res = await adminFetch('/api/admin/about', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Save failed.');
      onSaved(data.about);
      onNotify('About Page updated successfully.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Save failed.', true);
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={handleSave} className="space-y-6 max-w-4xl">
      <div>
        <h2 className="font-display text-2xl font-semibold text-[#0B192C]">Manage About Page</h2>
        <p className="text-sm text-slate-600 mt-1">
          Edit every section of the About page including biography, mission & vision headings, marketing approach steps, and agency differentiators.
        </p>
      </div>

      {/* Header & Biography */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <h3 className="font-display text-lg font-semibold text-[#0B192C]">1. Header & Specialist Biography</h3>
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Page Kicker</label>
          <input
            type="text"
            value={form.heroKicker}
            onChange={(e) => setForm({ ...form, heroKicker: e.target.value })}
            className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
          />
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Page Headline</label>
          <input
            type="text"
            value={form.heroHeading}
            onChange={(e) => setForm({ ...form, heroHeading: e.target.value })}
            className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
          />
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Page Subheadline</label>
          <input
            type="text"
            value={form.heroSubheading}
            onChange={(e) => setForm({ ...form, heroSubheading: e.target.value })}
            className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Specialist Name</label>
            <input
              type="text"
              value={form.specialistName}
              onChange={(e) => setForm({ ...form, specialistName: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Specialist Title</label>
            <input
              type="text"
              value={form.specialistTitle}
              onChange={(e) => setForm({ ...form, specialistTitle: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
        </div>

        <MediaField
          label="Specialist Portrait Photograph"
          value={form.portraitUrl}
          onChange={(url) => setForm({ ...form, portraitUrl: url })}
          assetType="author_photo"
          mediaLibrary={mediaLibrary}
          onMediaUploaded={onMediaUploaded}
        />

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Professional Biography (Separate paragraphs with a blank line)
          </label>
          <textarea
            rows={7}
            value={bioText}
            onChange={(e) => setBioText(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-sm leading-relaxed"
          />
        </div>
      </div>

      {/* Mission & Vision */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <h3 className="font-display text-lg font-semibold text-[#0B192C]">2. Mission & Vision</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div className="space-y-3 p-4 rounded-lg bg-[#F8F9FB] border border-slate-200">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Mission Label</label>
              <input
                type="text"
                value={form.missionLabel}
                onChange={(e) => setForm({ ...form, missionLabel: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Mission Heading</label>
              <input
                type="text"
                value={form.missionHeading}
                onChange={(e) => setForm({ ...form, missionHeading: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Mission Statement</label>
              <textarea
                rows={3}
                value={form.mission}
                onChange={(e) => setForm({ ...form, mission: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-sm"
              />
            </div>
          </div>

          <div className="space-y-3 p-4 rounded-lg bg-[#F8F9FB] border border-slate-200">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Vision Label</label>
              <input
                type="text"
                value={form.visionLabel}
                onChange={(e) => setForm({ ...form, visionLabel: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Vision Heading</label>
              <input
                type="text"
                value={form.visionHeading}
                onChange={(e) => setForm({ ...form, visionHeading: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Vision Statement</label>
              <textarea
                rows={3}
                value={form.vision}
                onChange={(e) => setForm({ ...form, vision: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-sm"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Approach to Book Marketing */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
        <h3 className="font-display text-lg font-semibold text-[#0B192C]">3. Marketing Approach Steps</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Approach Kicker</label>
            <input
              type="text"
              value={form.approachKicker}
              onChange={(e) => setForm({ ...form, approachKicker: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Approach Heading</label>
            <input
              type="text"
              value={form.approachHeading}
              onChange={(e) => setForm({ ...form, approachHeading: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Approach Subheading</label>
          <textarea
            rows={2}
            value={form.approachSubheading}
            onChange={(e) => setForm({ ...form, approachSubheading: e.target.value })}
            className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
          />
        </div>

        <div className="flex items-center justify-between pt-2">
          <span className="text-xs font-semibold text-slate-700">Approach Stages</span>
          <button
            type="button"
            onClick={() =>
              setForm({
                ...form,
                marketingApproach: [
                  ...form.marketingApproach,
                  { title: 'New Stage', description: 'Stage description' },
                ],
              })
            }
            className="inline-flex items-center gap-1 text-xs font-semibold text-[#8F6A10] hover:underline"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Stage</span>
          </button>
        </div>
        <div className="space-y-3">
          {form.marketingApproach.map((step, idx) => (
            <div key={idx} className="p-4 rounded-lg bg-[#F8F9FB] border border-slate-200 space-y-2.5">
              <div className="flex items-center gap-3">
                <input
                  type="text"
                  value={step.title}
                  onChange={(e) => {
                    const next = [...form.marketingApproach];
                    next[idx] = { ...next[idx], title: e.target.value };
                    setForm({ ...form, marketingApproach: next });
                  }}
                  className="flex-1 px-3 py-2 rounded-lg border border-slate-300 bg-white text-sm font-medium"
                />
                <button
                  type="button"
                  aria-label="Remove stage"
                  onClick={() =>
                    setForm({
                      ...form,
                      marketingApproach: form.marketingApproach.filter((_, i) => i !== idx),
                    })
                  }
                  className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              <textarea
                rows={2}
                value={step.description}
                onChange={(e) => {
                  const next = [...form.marketingApproach];
                  next[idx] = { ...next[idx], description: e.target.value };
                  setForm({ ...form, marketingApproach: next });
                }}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-sm"
              />
            </div>
          ))}
        </div>
      </div>

      {/* Commitment & Why Work With Us */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
        <h3 className="font-display text-lg font-semibold text-[#0B192C]">4. Commitment, Why Partner & CTA Buttons</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Commitment Kicker</label>
            <input
              type="text"
              value={form.commitmentKicker}
              onChange={(e) => setForm({ ...form, commitmentKicker: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Why Partner Heading</label>
            <input
              type="text"
              value={form.whyHeading}
              onChange={(e) => setForm({ ...form, whyHeading: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Commitment Statement</label>
          <textarea
            rows={3}
            value={form.commitmentStatement}
            onChange={(e) => setForm({ ...form, commitmentStatement: e.target.value })}
            className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
          />
        </div>

        <div className="flex items-center justify-between pt-2">
          <span className="text-xs font-semibold text-slate-700">Why Partner Pillars</span>
          <button
            type="button"
            onClick={() =>
              setForm({
                ...form,
                whyWorkWithUs: [
                  ...form.whyWorkWithUs,
                  { title: 'New Advantage', description: 'Supporting detail' },
                ],
              })
            }
            className="inline-flex items-center gap-1 text-xs font-semibold text-[#8F6A10] hover:underline"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Reason</span>
          </button>
        </div>
        <div className="space-y-3">
          {form.whyWorkWithUs.map((reason, idx) => (
            <div key={idx} className="p-4 rounded-lg bg-[#F8F9FB] border border-slate-200 space-y-2.5">
              <div className="flex items-center gap-3">
                <input
                  type="text"
                  value={reason.title}
                  onChange={(e) => {
                    const next = [...form.whyWorkWithUs];
                    next[idx] = { ...next[idx], title: e.target.value };
                    setForm({ ...form, whyWorkWithUs: next });
                  }}
                  className="flex-1 px-3 py-2 rounded-lg border border-slate-300 bg-white text-sm font-medium"
                />
                <button
                  type="button"
                  aria-label="Remove reason"
                  onClick={() =>
                    setForm({
                      ...form,
                      whyWorkWithUs: form.whyWorkWithUs.filter((_, i) => i !== idx),
                    })
                  }
                  className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              <textarea
                rows={2}
                value={reason.description}
                onChange={(e) => {
                  const next = [...form.whyWorkWithUs];
                  next[idx] = { ...next[idx], description: e.target.value };
                  setForm({ ...form, whyWorkWithUs: next });
                }}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-sm"
              />
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Primary CTA Button Label</label>
            <input
              type="text"
              value={form.primaryCtaLabel}
              onChange={(e) => setForm({ ...form, primaryCtaLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Secondary CTA Button Label</label>
            <input
              type="text"
              value={form.secondaryCtaLabel}
              onChange={(e) => setForm({ ...form, secondaryCtaLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
        </div>
      </div>

      <button
        type="submit"
        disabled={saving}
        className="px-6 py-3 rounded-lg bg-[#0B192C] text-white text-sm font-semibold hover:bg-[#132945] disabled:opacity-60"
      >
        {saving ? 'Saving About Page...' : 'Save About Page'}
      </button>
    </form>
  );
}

interface WebsiteSettingsProps {
  settings: WebsiteSettings;
  pagesCopy: PagesCopyContent;
  onSaved: (updated: WebsiteSettings) => void;
  onPagesCopySaved: (updated: PagesCopyContent) => void;
  onNotify: (msg: string, isError?: boolean) => void;
}

export function WebsiteSettingsPanel({
  settings,
  pagesCopy,
  onSaved,
  onPagesCopySaved,
  onNotify,
}: WebsiteSettingsProps) {
  const [form, setForm] = useState<WebsiteSettings>(settings);
  const [copyForm, setCopyForm] = useState<PagesCopyContent>(pagesCopy);
  const [saving, setSaving] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const [resSettings, resCopy] = await Promise.all([
        adminFetch('/api/admin/settings', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify(form),
        }),
        adminFetch('/api/admin/pages-copy', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify(copyForm),
        }),
      ]);

      const dataSettings = await resSettings.json();
      if (!resSettings.ok) throw new Error(dataSettings.error || 'Failed to update settings.');

      const dataCopy = await resCopy.json();
      if (!resCopy.ok) throw new Error(dataCopy.error || 'Failed to update page headers copy.');

      onSaved(dataSettings.settings);
      onPagesCopySaved(dataCopy.pagesCopy);
      onNotify('Website settings & page copy saved.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Save failed.', true);
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={handleSave} className="space-y-6 max-w-4xl">
      <div>
        <h2 className="font-display text-2xl font-semibold text-[#0B192C]">Website Settings & Global Copy</h2>
        <p className="text-sm text-slate-600 mt-1">
          Configure agency contact details, social links, SEO metadata, footer note, and every subpage header & button label.
        </p>
      </div>

      {/* Agency Identity & SEO */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <h3 className="font-display text-lg font-semibold text-[#0B192C]">Agency Identity, Socials & SEO</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Business Name</label>
            <input
              type="text"
              value={form.businessName}
              onChange={(e) => setForm({ ...form, businessName: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Public Contact Email</label>
            <input
              type="email"
              value={form.contactEmail}
              onChange={(e) => setForm({ ...form, contactEmail: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Specialist Name</label>
            <input
              type="text"
              value={form.specialistName}
              onChange={(e) => setForm({ ...form, specialistName: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Specialist Title</label>
            <input
              type="text"
              value={form.specialistTitle}
              onChange={(e) => setForm({ ...form, specialistTitle: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold text-slate-700 mb-1">Agency Location / Scope</label>
            <input
              type="text"
              value={form.location}
              onChange={(e) => setForm({ ...form, location: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Business Description</label>
          <textarea
            rows={3}
            value={form.businessDescription}
            onChange={(e) => setForm({ ...form, businessDescription: e.target.value })}
            className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
          />
        </div>

        <div className="pt-2 border-t border-slate-100 space-y-3">
          <h4 className="text-sm font-semibold text-[#0B192C]">Social Media Links</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {(['linkedin', 'instagram', 'x', 'facebook', 'youtube'] as const).map((net) => (
              <div key={net}>
                <label className="block text-xs font-semibold text-slate-700 mb-1 capitalize">
                  {net === 'x' ? 'X (Twitter)' : net}
                </label>
                <input
                  type="url"
                  value={form.socialLinks[net] || ''}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      socialLinks: { ...form.socialLinks, [net]: e.target.value },
                    })
                  }
                  placeholder={`https://${net}.com/...`}
                  className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
                />
              </div>
            ))}
          </div>
        </div>

        <div className="pt-2 border-t border-slate-100 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Browser SEO Title</label>
            <input
              type="text"
              value={form.seoTitle}
              onChange={(e) => setForm({ ...form, seoTitle: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Browser SEO Description</label>
            <textarea
              rows={2}
              value={form.seoDescription}
              onChange={(e) => setForm({ ...form, seoDescription: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Footer Note</label>
            <input
              type="text"
              value={form.footerNote}
              onChange={(e) => setForm({ ...form, footerNote: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
        </div>
      </div>

      {/* Navigation, Header & Footer Labels */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <div>
          <h3 className="font-display text-lg font-semibold text-[#0B192C]">Navigation, Header & Footer Copy</h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Customize every top navigation link, header button, and footer heading/button across the entire site.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Home Nav Label</label>
            <input
              type="text"
              value={copyForm.navHomeLabel}
              onChange={(e) => setCopyForm({ ...copyForm, navHomeLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">About Nav Label</label>
            <input
              type="text"
              value={copyForm.navAboutLabel}
              onChange={(e) => setCopyForm({ ...copyForm, navAboutLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Services Nav Label</label>
            <input
              type="text"
              value={copyForm.navServicesLabel}
              onChange={(e) => setCopyForm({ ...copyForm, navServicesLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Portfolio Nav Label</label>
            <input
              type="text"
              value={copyForm.navPortfolioLabel}
              onChange={(e) => setCopyForm({ ...copyForm, navPortfolioLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Featured Books Nav Label</label>
            <input
              type="text"
              value={copyForm.navBooksLabel}
              onChange={(e) => setCopyForm({ ...copyForm, navBooksLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Contact Nav Label</label>
            <input
              type="text"
              value={copyForm.navContactLabel}
              onChange={(e) => setCopyForm({ ...copyForm, navContactLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Admin Button Label</label>
            <input
              type="text"
              value={copyForm.navAdminLabel}
              onChange={(e) => setCopyForm({ ...copyForm, navAdminLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Header CTA Button Label</label>
            <input
              type="text"
              value={copyForm.headerCtaLabel}
              onChange={(e) => setCopyForm({ ...copyForm, headerCtaLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
        </div>

        <div className="pt-3 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Footer Inquiries Label</label>
            <input
              type="text"
              value={copyForm.footerInquiriesLabel}
              onChange={(e) => setCopyForm({ ...copyForm, footerInquiriesLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Footer Nav Column Heading</label>
            <input
              type="text"
              value={copyForm.footerNavHeading}
              onChange={(e) => setCopyForm({ ...copyForm, footerNavHeading: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Footer Connect Heading</label>
            <input
              type="text"
              value={copyForm.footerConnectHeading}
              onChange={(e) => setCopyForm({ ...copyForm, footerConnectHeading: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Footer CTA Button Label</label>
            <input
              type="text"
              value={copyForm.footerCtaLabel}
              onChange={(e) => setCopyForm({ ...copyForm, footerCtaLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
        </div>
      </div>

      {/* Shared Card & Action Labels */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <div>
          <h3 className="font-display text-lg font-semibold text-[#0B192C]">Shared Card, Modal & Action Labels</h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Labels reused on cards, modals, and links across the homepage and subpages.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Request Service Link Label</label>
            <input
              type="text"
              value={copyForm.requestServiceLabel}
              onChange={(e) => setCopyForm({ ...copyForm, requestServiceLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Inspect Campaign Label</label>
            <input
              type="text"
              value={copyForm.inspectCampaignLabel}
              onChange={(e) => setCopyForm({ ...copyForm, inspectCampaignLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Video Preview Tag Label</label>
            <input
              type="text"
              value={copyForm.videoPreviewLabel}
              onChange={(e) => setCopyForm({ ...copyForm, videoPreviewLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">View Book Feature Label</label>
            <input
              type="text"
              value={copyForm.viewFeatureLabel}
              onChange={(e) => setCopyForm({ ...copyForm, viewFeatureLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Book Store Link Label</label>
            <input
              type="text"
              value={copyForm.bookLinkLabel}
              onChange={(e) => setCopyForm({ ...copyForm, bookLinkLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Modal Request Campaign CTA</label>
            <input
              type="text"
              value={copyForm.modalRequestCampaignLabel}
              onChange={(e) => setCopyForm({ ...copyForm, modalRequestCampaignLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Author Website Link Label</label>
            <input
              type="text"
              value={copyForm.authorWebsiteLabel}
              onChange={(e) => setCopyForm({ ...copyForm, authorWebsiteLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Author Social Link Label</label>
            <input
              type="text"
              value={copyForm.authorSocialLabel}
              onChange={(e) => setCopyForm({ ...copyForm, authorSocialLabel: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Empty Testimonials Notice Text</label>
          <input
            type="text"
            value={copyForm.emptyTestimonialsText}
            onChange={(e) => setCopyForm({ ...copyForm, emptyTestimonialsText: e.target.value })}
            className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
          />
        </div>
      </div>

      {/* Subpage Headers & Page-Specific Copy */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-6">
        <div>
          <h3 className="font-display text-lg font-semibold text-[#0B192C]">Subpage Headers, Labels & Form Copy</h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Customize every heading, filter button, detail label, and form field across Services, Portfolio, Featured Books, and Contact pages.
          </p>
        </div>

        {/* Services Page Copy */}
        <div className="space-y-3">
          <h4 className="text-sm font-semibold text-[#0B192C]">Services Page Copy</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Services Kicker</label>
              <input
                type="text"
                value={copyForm.servicesKicker}
                onChange={(e) => setCopyForm({ ...copyForm, servicesKicker: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Service Number Prefix</label>
              <input
                type="text"
                value={copyForm.serviceNumberPrefix}
                onChange={(e) => setCopyForm({ ...copyForm, serviceNumberPrefix: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Deliverables Heading</label>
              <input
                type="text"
                value={copyForm.deliverablesHeading}
                onChange={(e) => setCopyForm({ ...copyForm, deliverablesHeading: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Services Bottom CTA Button</label>
              <input
                type="text"
                value={copyForm.servicesBottomCta}
                onChange={(e) => setCopyForm({ ...copyForm, servicesBottomCta: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Services Page Heading</label>
            <input
              type="text"
              value={copyForm.servicesHeading}
              onChange={(e) => setCopyForm({ ...copyForm, servicesHeading: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Services Page Subheading</label>
            <textarea
              rows={2}
              value={copyForm.servicesSubheading}
              onChange={(e) => setCopyForm({ ...copyForm, servicesSubheading: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Services Bottom Banner Heading</label>
              <input
                type="text"
                value={copyForm.servicesBottomHeading}
                onChange={(e) => setCopyForm({ ...copyForm, servicesBottomHeading: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Services Bottom Banner Body</label>
              <input
                type="text"
                value={copyForm.servicesBottomBody}
                onChange={(e) => setCopyForm({ ...copyForm, servicesBottomBody: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
          </div>
        </div>

        {/* Portfolio Page Copy */}
        <div className="pt-4 border-t border-slate-100 space-y-3">
          <h4 className="text-sm font-semibold text-[#0B192C]">Portfolio Page Copy</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Portfolio Kicker</label>
              <input
                type="text"
                value={copyForm.portfolioKicker}
                onChange={(e) => setCopyForm({ ...copyForm, portfolioKicker: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Portfolio Heading</label>
              <input
                type="text"
                value={copyForm.portfolioHeading}
                onChange={(e) => setCopyForm({ ...copyForm, portfolioHeading: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Portfolio Subheading</label>
            <textarea
              rows={2}
              value={copyForm.portfolioSubheading}
              onChange={(e) => setCopyForm({ ...copyForm, portfolioSubheading: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">All Filter Button Label</label>
              <input
                type="text"
                value={copyForm.portfolioAllFilterLabel}
                onChange={(e) => setCopyForm({ ...copyForm, portfolioAllFilterLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Watch Trailer Button Label</label>
              <input
                type="text"
                value={copyForm.portfolioWatchTrailerLabel}
                onChange={(e) => setCopyForm({ ...copyForm, portfolioWatchTrailerLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">View Details Button Label</label>
              <input
                type="text"
                value={copyForm.portfolioViewDetailsLabel}
                onChange={(e) => setCopyForm({ ...copyForm, portfolioViewDetailsLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Inquire Link Label</label>
              <input
                type="text"
                value={copyForm.portfolioInquireLabel}
                onChange={(e) => setCopyForm({ ...copyForm, portfolioInquireLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Modal Book Prefix Label</label>
              <input
                type="text"
                value={copyForm.portfolioModalBookLabel}
                onChange={(e) => setCopyForm({ ...copyForm, portfolioModalBookLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Modal CTA Button Label</label>
              <input
                type="text"
                value={copyForm.portfolioModalCtaLabel}
                onChange={(e) => setCopyForm({ ...copyForm, portfolioModalCtaLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
          </div>
        </div>

        {/* Featured Books & Authors Page Copy */}
        <div className="pt-4 border-t border-slate-100 space-y-3">
          <h4 className="text-sm font-semibold text-[#0B192C]">Featured Books & Authors Page Copy</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Books Page Kicker</label>
              <input
                type="text"
                value={copyForm.booksKicker}
                onChange={(e) => setCopyForm({ ...copyForm, booksKicker: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Books Page Heading</label>
              <input
                type="text"
                value={copyForm.booksHeading}
                onChange={(e) => setCopyForm({ ...copyForm, booksHeading: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Books Page Subheading</label>
            <textarea
              rows={2}
              value={copyForm.booksSubheading}
              onChange={(e) => setCopyForm({ ...copyForm, booksSubheading: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Book Card Store Short Label</label>
              <input
                type="text"
                value={copyForm.bookStoreShortLabel}
                onChange={(e) => setCopyForm({ ...copyForm, bookStoreShortLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Authors Directory Kicker</label>
              <input
                type="text"
                value={copyForm.authorsKicker}
                onChange={(e) => setCopyForm({ ...copyForm, authorsKicker: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Authors Directory Heading</label>
              <input
                type="text"
                value={copyForm.authorsHeading}
                onChange={(e) => setCopyForm({ ...copyForm, authorsHeading: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Back To Books Link Label</label>
              <input
                type="text"
                value={copyForm.backToBooksLabel}
                onChange={(e) => setCopyForm({ ...copyForm, backToBooksLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Book About Section Heading</label>
              <input
                type="text"
                value={copyForm.bookAboutHeading}
                onChange={(e) => setCopyForm({ ...copyForm, bookAboutHeading: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Book Spotlight Section Heading</label>
              <input
                type="text"
                value={copyForm.bookSpotlightHeading}
                onChange={(e) => setCopyForm({ ...copyForm, bookSpotlightHeading: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Promotional Scope Label</label>
              <input
                type="text"
                value={copyForm.bookPromoScopeLabel}
                onChange={(e) => setCopyForm({ ...copyForm, bookPromoScopeLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Purchase Book CTA Label</label>
              <input
                type="text"
                value={copyForm.bookPurchaseLabel}
                onChange={(e) => setCopyForm({ ...copyForm, bookPurchaseLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Promote Similar Book CTA</label>
              <input
                type="text"
                value={copyForm.bookPromoteCtaLabel}
                onChange={(e) => setCopyForm({ ...copyForm, bookPromoteCtaLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Book Banner Section Heading</label>
              <input
                type="text"
                value={copyForm.bookBannerHeading}
                onChange={(e) => setCopyForm({ ...copyForm, bookBannerHeading: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Book Trailer Section Heading</label>
              <input
                type="text"
                value={copyForm.bookTrailerHeading}
                onChange={(e) => setCopyForm({ ...copyForm, bookTrailerHeading: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
          </div>
        </div>

        {/* Contact Page Copy */}
        <div className="pt-4 border-t border-slate-100 space-y-3">
          <h4 className="text-sm font-semibold text-[#0B192C]">Contact & Quote Request Page Copy</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Contact Kicker</label>
              <input
                type="text"
                value={copyForm.contactKicker}
                onChange={(e) => setCopyForm({ ...copyForm, contactKicker: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Contact Heading</label>
              <input
                type="text"
                value={copyForm.contactHeading}
                onChange={(e) => setCopyForm({ ...copyForm, contactHeading: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Contact Subheading</label>
            <textarea
              rows={2}
              value={copyForm.contactSubheading}
              onChange={(e) => setCopyForm({ ...copyForm, contactSubheading: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Form Card Heading</label>
              <input
                type="text"
                value={copyForm.contactFormHeading}
                onChange={(e) => setCopyForm({ ...copyForm, contactFormHeading: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name Field Label</label>
              <input
                type="text"
                value={copyForm.contactNameLabel}
                onChange={(e) => setCopyForm({ ...copyForm, contactNameLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Email Field Label</label>
              <input
                type="text"
                value={copyForm.contactEmailLabel}
                onChange={(e) => setCopyForm({ ...copyForm, contactEmailLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Book Title Field Label</label>
              <input
                type="text"
                value={copyForm.contactBookTitleLabel}
                onChange={(e) => setCopyForm({ ...copyForm, contactBookTitleLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Genre Field Label</label>
              <input
                type="text"
                value={copyForm.contactGenreLabel}
                onChange={(e) => setCopyForm({ ...copyForm, contactGenreLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Author Website Field Label</label>
              <input
                type="text"
                value={copyForm.contactWebsiteLabel}
                onChange={(e) => setCopyForm({ ...copyForm, contactWebsiteLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Service Select Field Label</label>
              <input
                type="text"
                value={copyForm.contactServiceLabel}
                onChange={(e) => setCopyForm({ ...copyForm, contactServiceLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Extra Bundle Option Label</label>
              <input
                type="text"
                value={copyForm.contactExtraServiceOption}
                onChange={(e) => setCopyForm({ ...copyForm, contactExtraServiceOption: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Message Field Label</label>
              <input
                type="text"
                value={copyForm.contactMessageLabel}
                onChange={(e) => setCopyForm({ ...copyForm, contactMessageLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Upload Field Label</label>
              <input
                type="text"
                value={copyForm.contactUploadLabel}
                onChange={(e) => setCopyForm({ ...copyForm, contactUploadLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Upload File Hint</label>
              <input
                type="text"
                value={copyForm.contactUploadHint}
                onChange={(e) => setCopyForm({ ...copyForm, contactUploadHint: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Submit Button Label</label>
              <input
                type="text"
                value={copyForm.contactSubmitLabel}
                onChange={(e) => setCopyForm({ ...copyForm, contactSubmitLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Success Confirmation Title</label>
              <input
                type="text"
                value={copyForm.contactSuccessTitle}
                onChange={(e) => setCopyForm({ ...copyForm, contactSuccessTitle: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Sidebar Card Kicker</label>
              <input
                type="text"
                value={copyForm.contactSidebarKicker}
                onChange={(e) => setCopyForm({ ...copyForm, contactSidebarKicker: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Sidebar Email Label</label>
              <input
                type="text"
                value={copyForm.contactSidebarEmailLabel}
                onChange={(e) => setCopyForm({ ...copyForm, contactSidebarEmailLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Sidebar Location Label</label>
              <input
                type="text"
                value={copyForm.contactSidebarLocationLabel}
                onChange={(e) => setCopyForm({ ...copyForm, contactSidebarLocationLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Sidebar Channels Label</label>
              <input
                type="text"
                value={copyForm.contactSidebarChannelsLabel}
                onChange={(e) => setCopyForm({ ...copyForm, contactSidebarChannelsLabel: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
          </div>
        </div>
      </div>

      <button
        type="submit"
        disabled={saving}
        className="px-6 py-3 rounded-lg bg-[#0B192C] text-white text-sm font-semibold hover:bg-[#132945] disabled:opacity-60"
      >
        {saving ? 'Saving Settings & Page Copy...' : 'Save Website Settings & Page Copy'}
      </button>
    </form>
  );
}

