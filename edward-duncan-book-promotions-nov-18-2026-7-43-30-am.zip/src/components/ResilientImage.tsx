import { BookOpen } from 'lucide-react';
import { useState } from 'react';

interface ResilientImageProps {
  src?: string;
  alt: string;
  className?: string;
  fallbackTitle?: string;
}

export function ResilientImage({ src, alt, className = '', fallbackTitle }: ResilientImageProps) {
  const [failed, setFailed] = useState(false);

  if (!src || failed) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-[#0B192C] via-[#132945] to-[#1E293B] text-white/85 p-6 text-center ${className}`}
      >
        <BookOpen className="w-8 h-8 text-[#D9B44A] mb-2 opacity-90" aria-hidden="true" />
        <span className="text-xs font-medium tracking-wide text-slate-200 max-w-[20ch] line-clamp-2">
          {fallbackTitle || alt}
        </span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={className}
    />
  );
}
