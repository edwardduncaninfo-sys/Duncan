import {
  BookOpen,
  Briefcase,
  FolderKanban,
  Inbox,
  KeyRound,
  LayoutDashboard,
  Lock,
  LogOut,
  Menu,
  Settings,
  Shield,
  Sparkles,
  X,
} from 'lucide-react';
import React, { useEffect, useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useSiteData } from '../context/SiteDataContext';
import { adminFetch, clearAdminToken } from '../utils/adminAuth';

const HEADER_NAV_LINKS = [
  { to: '/about', label: 'About' },
  { to: '/services', label: 'Services' },
  { to: '/portfolio', label: 'Portfolio' },
  { to: '/books', label: 'Featured Books' },
  { to: '/contact', label: 'Contact' },
];

const ADMIN_DRAWER_LINKS = [
  { tab: 'overview', label: 'Dashboard Overview', icon: LayoutDashboard },
  { tab: 'services', label: 'Manage Services', icon: Briefcase },
  { tab: 'portfolio', label: 'Manage Portfolio', icon: FolderKanban },
  { tab: 'upload-spotlight', label: 'Promotional Upload Center', icon: Sparkles },
  { tab: 'books', label: 'Manage Featured Books', icon: BookOpen },
  { tab: 'submissions', label: 'Contact Form Submissions', icon: Inbox },
  { tab: 'settings', label: 'Website Settings', icon: Settings },
  { tab: 'security', label: 'Security & Account', icon: Shield },
];

export function PublicLayout({ children }: { children: React.ReactNode }) {
  const { siteData } = useSiteData();
  const navigate = useNavigate();
  const [adminDrawerOpen, setAdminDrawerOpen] = useState(false);
  const [isOwnerAuthenticated, setIsOwnerAuthenticated] = useState(false);
  const [ownerEmail, setOwnerEmail] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    adminFetch('/api/auth/me')
      .then((res) => res.json())
      .then((data) => {
        if (active) {
          setIsOwnerAuthenticated(Boolean(data?.authenticated));
          setOwnerEmail(data?.owner?.email || null);
        }
      })
      .catch(() => {
        if (active) {
          setIsOwnerAuthenticated(false);
        }
      });
    return () => {
      active = false;
    };
  }, []);

  const handleLogout = async () => {
    await adminFetch('/api/auth/logout', { method: 'POST' });
    clearAdminToken();
    setIsOwnerAuthenticated(false);
    setOwnerEmail(null);
    setAdminDrawerOpen(false);
    navigate('/');
  };

  const pagesCopy = siteData?.pagesCopy;
  const headerNavLinks = [
    { to: '/about', label: pagesCopy?.navAboutLabel || 'About' },
    { to: '/services', label: pagesCopy?.navServicesLabel || 'Services' },
    { to: '/portfolio', label: pagesCopy?.navPortfolioLabel || 'Portfolio' },
    { to: '/books', label: pagesCopy?.navBooksLabel || 'Featured Books' },
    { to: '/contact', label: pagesCopy?.navContactLabel || 'Contact' },
  ];

  const businessName = siteData?.settings.businessName || 'Edward Duncan Book Promotions';
  const contactEmail = siteData?.settings.contactEmail || 'edwardduncan.info@gmail.com';
  const footerNote =
    siteData?.settings.footerNote ||
    'Strategic Book Marketing, Author Branding & Literary Visibility Worldwide.';
  const socialLinks = siteData?.settings.socialLinks;

  const activeSocials = [
    { label: 'LinkedIn', url: socialLinks?.linkedin },
    { label: 'Instagram', url: socialLinks?.instagram },
    { label: 'X', url: socialLinks?.x },
    { label: 'Facebook', url: socialLinks?.facebook },
    { label: 'YouTube', url: socialLinks?.youtube },
  ].filter((item) => Boolean(item.url));

  return (
    <div className="min-h-screen flex flex-col bg-white text-slate-900">
      {/* Main Website Header */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4 lg:gap-8">
          {/* Zone 1: Brand wordmark */}
          <Link
            to="/"
            onClick={() => setAdminDrawerOpen(false)}
            className="font-display text-base sm:text-lg xl:text-xl font-semibold tracking-tight text-[#0B192C] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#C59B27]"
          >
            {businessName}
          </Link>

          {/* Zone 2: Public Navigation Links directly in the header */}
          <nav aria-label="Primary Navigation" className="hidden md:flex items-center gap-3.5 lg:gap-6">
            {headerNavLinks.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `text-xs lg:text-sm font-medium whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors duration-150 ${
                    isActive
                      ? 'text-[#0B192C] border-[#C59B27]'
                      : 'text-slate-600 border-transparent hover:text-[#0B192C] hover:border-slate-300'
                  }`
                }
              >
                {item.label}
              </NavLink>
            ))}
          </nav>

          {/* Zone 3: Primary Quote CTA + Admin Dashboard Menu Button */}
          <div className="flex items-center gap-2.5 shrink-0">
            <Link
              to="/contact"
              className="hidden sm:inline-flex items-center justify-center px-3.5 lg:px-5 py-2 lg:py-2.5 rounded-lg bg-[#0B192C] text-white text-xs lg:text-sm font-semibold hover:bg-[#132945] transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#C59B27]"
            >
              {pagesCopy?.headerCtaLabel || 'Get a Quote'}
            </Link>

            <button
              type="button"
              onClick={() => setAdminDrawerOpen((prev) => !prev)}
              aria-expanded={adminDrawerOpen}
              aria-label="Open Admin Dashboard Menu"
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 bg-white text-xs font-semibold text-[#0B192C] hover:border-[#C59B27] hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0"
            >
              {adminDrawerOpen ? (
                <X className="w-4 h-4 text-[#0B192C]" aria-hidden="true" />
              ) : (
                <Menu className="w-4 h-4 text-[#0B192C]" aria-hidden="true" />
              )}
              <span>{pagesCopy?.navAdminLabel || 'Admin Dashboard'}</span>
            </button>
          </div>
        </div>

        {/* Compact Header Strip on Narrow Mobile (< md) so public links stay in the header */}
        <nav
          aria-label="Mobile Header Navigation"
          className="md:hidden border-t border-slate-100 bg-[#F8F9FB] px-4 py-2 flex items-center gap-4 overflow-x-auto"
        >
          {headerNavLinks.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `text-xs font-medium whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
                  isActive
                    ? 'text-[#0B192C] border-[#C59B27]'
                    : 'text-slate-600 border-transparent hover:text-[#0B192C]'
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>

        {/* Admin Dashboard Navigation Button Drawer */}
        {adminDrawerOpen && (
          <div className="border-t border-slate-200 bg-[#0B192C] text-white shadow-xl">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
              {isOwnerAuthenticated ? (
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
                    <div>
                      <p className="text-xs font-semibold text-[#D9B44A]">
                        Owner Authenticated · {ownerEmail}
                      </p>
                      <h2 className="font-display text-xl font-semibold text-white">
                        Admin Dashboard Controls
                      </h2>
                    </div>
                    <div className="flex items-center gap-3">
                      <Link
                        to="/admin"
                        onClick={() => setAdminDrawerOpen(false)}
                        className="px-4 py-2 rounded-lg bg-[#C59B27] text-[#0B192C] text-xs font-semibold hover:bg-[#D9B44A] transition-colors"
                      >
                        Open Full Admin Dashboard
                      </Link>
                      <button
                        type="button"
                        onClick={handleLogout}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-700 text-xs font-semibold text-red-300 hover:bg-red-950/40"
                      >
                        <LogOut className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Logout</span>
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    {ADMIN_DRAWER_LINKS.map((item) => {
                      const Icon = item.icon;
                      return (
                        <Link
                          key={item.tab}
                          to={`/admin?tab=${item.tab}`}
                          onClick={() => setAdminDrawerOpen(false)}
                          className="flex items-center gap-2.5 px-3.5 py-2.5 rounded-lg bg-[#11223B] border border-slate-800 hover:border-[#C59B27] text-xs font-medium text-slate-200 hover:text-white transition-colors"
                        >
                          <Icon className="w-4 h-4 text-[#D9B44A] shrink-0" aria-hidden="true" />
                          <span className="truncate">{item.label}</span>
                        </Link>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg bg-[#11223B] border border-slate-700 flex items-center justify-center shrink-0">
                      <Lock className="w-4 h-4 text-[#D9B44A]" aria-hidden="true" />
                    </div>
                    <div>
                      <h2 className="font-display text-lg font-semibold text-white">
                        Private Owner Admin Dashboard
                      </h2>
                      <p className="text-xs text-slate-300 mt-0.5">
                        Sign in with your authorized owner account to manage pages, services, portfolio uploads, and contact submissions.
                      </p>
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-3 shrink-0">
                    <Link
                      to="/admin/login"
                      onClick={() => setAdminDrawerOpen(false)}
                      className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#C59B27] text-[#0B192C] text-xs font-semibold hover:bg-[#D9B44A] transition-colors"
                    >
                      <Lock className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>Owner Sign In</span>
                    </Link>
                    <Link
                      to="/admin/reset-password"
                      onClick={() => setAdminDrawerOpen(false)}
                      className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg border border-slate-700 text-xs font-medium text-slate-200 hover:bg-white/10 transition-colors"
                    >
                      <KeyRound className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>Reset Password</span>
                    </Link>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </header>

      <main className="flex-1">{children}</main>

      <footer className="bg-[#0B192C] text-slate-300 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-slate-800">
            <div className="md:col-span-5 space-y-4">
              <Link to="/" className="font-display text-2xl font-semibold text-white inline-block">
                {businessName}
              </Link>
              <p className="text-sm text-slate-300 leading-relaxed max-w-md">{footerNote}</p>
              <p className="text-sm text-slate-400">
                {pagesCopy?.footerInquiriesLabel || 'Direct Inquiries:'}{' '}
                <a
                  href={`mailto:${contactEmail}`}
                  className="text-[#D9B44A] hover:underline font-medium"
                >
                  {contactEmail}
                </a>
              </p>
            </div>

            <div className="md:col-span-4 space-y-3">
              <h3 className="text-sm font-semibold text-white tracking-wide">
                {pagesCopy?.footerNavHeading || 'Agency Navigation'}
              </h3>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link to="/" className="hover:text-white transition-colors">
                    {pagesCopy?.navHomeLabel || 'Homepage'}
                  </Link>
                </li>
                {headerNavLinks.map((item) => (
                  <li key={item.to}>
                    <Link to={item.to} className="hover:text-white transition-colors">
                      {item.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div className="md:col-span-3 space-y-3">
              <h3 className="text-sm font-semibold text-white tracking-wide">
                {pagesCopy?.footerConnectHeading || 'Connect'}
              </h3>
              {activeSocials.length > 0 ? (
                <ul className="space-y-2 text-sm">
                  {activeSocials.map((soc) => (
                    <li key={soc.label}>
                      <a
                        href={soc.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="hover:text-[#D9B44A] transition-colors"
                      >
                        {soc.label}
                      </a>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-sm text-slate-400">Social channels configured in agency settings.</p>
              )}
              <div className="pt-2">
                <Link
                  to="/contact"
                  className="inline-flex items-center px-4 py-2 rounded-lg border border-[#C59B27]/60 text-[#D9B44A] text-xs font-semibold hover:bg-[#C59B27] hover:text-[#0B192C] transition-colors"
                >
                  {pagesCopy?.footerCtaLabel || 'Request Campaign Consultation'}
                </Link>
              </div>
            </div>
          </div>

          <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
            <p>
              &copy; {new Date().getFullYear()} {businessName}. All rights reserved.
            </p>
            <div className="flex items-center gap-6">
              <span>{siteData?.settings.location || 'International Author Services'}</span>
              <span aria-hidden="true">·</span>
              <Link to="/admin" className="hover:text-slate-200 transition-colors">
                {pagesCopy?.navAdminLabel || 'Admin Dashboard'}
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
