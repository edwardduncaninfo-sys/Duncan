import {
  BookOpen,
  Briefcase,
  ExternalLink,
  FileText,
  Film,
  FolderKanban,
  Home,
  Image as ImageIcon,
  Inbox,
  LayoutDashboard,
  LogOut,
  Menu,
  MessageSquareQuote,
  Settings,
  Shield,
  Sparkles,
  Users,
  X,
} from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { adminFetch, clearAdminToken } from '../../utils/adminAuth';
import {
  ManageAuthorsPanel,
  ManageFeaturedBooksPanel,
  ManagePortfolioPanel,
  ManageServicesPanel,
  ManageTestimonialsPanel,
} from '../../components/admin/AdminCatalogManagers';
import {
  ContactSubmissionsPanel,
  MediaLibraryPanel,
  SecuritySettingsPanel,
} from '../../components/admin/AdminOperationsPanels';
import {
  AdminOverviewPanel,
  ManageAboutPanel,
  ManageHomepagePanel,
  PromotionalUploadCenterPanel,
  WebsiteSettingsPanel,
} from '../../components/admin/AdminSectionsContent';
import { useSiteData } from '../../context/SiteDataContext';
import type {
  AboutContent,
  AuthorProfile,
  ContactSubmission,
  FeaturedBook,
  HomepageContent,
  MediaAsset,
  PagesCopyContent,
  PortfolioItem,
  ServiceItem,
  TestimonialItem,
  WebsiteSettings,
} from '../../types/cms';

interface AdminBootstrapData {
  owner: {
    email: string;
    lastLoginAt: string | null;
    updatedAt: string;
    recoveryKeyPreview: string;
  };
  currentSessionId: string;
  sessions: {
    id: string;
    createdAt: string;
    expiresAt: string;
    userAgent: string;
    ipAddress: string;
    isCurrent: boolean;
  }[];
  settings: WebsiteSettings;
  homepage: HomepageContent;
  about: AboutContent;
  pagesCopy: PagesCopyContent;
  services: ServiceItem[];
  portfolio: PortfolioItem[];
  featuredBooks: FeaturedBook[];
  authors: AuthorProfile[];
  testimonials: TestimonialItem[];
  contactSubmissions: ContactSubmission[];
  mediaLibrary: MediaAsset[];
}

const SIDEBAR_ITEMS = [
  { id: 'overview', label: 'Dashboard Overview', icon: LayoutDashboard },
  { id: 'services', label: 'Manage Services', icon: Briefcase },
  { id: 'portfolio', label: 'Manage Portfolio', icon: FolderKanban },
  { id: 'upload-spotlight', label: 'Upload Author Spotlight', icon: Sparkles },
  { id: 'upload-banners', label: 'Upload Promotional Banners', icon: ImageIcon },
  { id: 'upload-trailers', label: 'Upload Book Trailers', icon: Film },
  { id: 'books', label: 'Manage Featured Books', icon: BookOpen },
  { id: 'authors', label: 'Manage Authors', icon: Users },
  { id: 'testimonials', label: 'Manage Testimonials', icon: MessageSquareQuote },
  { id: 'homepage', label: 'Manage Homepage', icon: Home },
  { id: 'about', label: 'Manage About Page', icon: FileText },
  { id: 'submissions', label: 'Contact Form Submissions', icon: Inbox },
  { id: 'media', label: 'Media Library', icon: ImageIcon },
  { id: 'settings', label: 'Website Settings', icon: Settings },
  { id: 'security', label: 'Security and Account Settings', icon: Shield },
] as const;

export function AdminDashboardPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { refreshSiteData } = useSiteData();

  const requestedTab = searchParams.get('tab');
  const validTab = SIDEBAR_ITEMS.some((i) => i.id === requestedTab) ? (requestedTab as string) : 'overview';

  const [data, setData] = useState<AdminBootstrapData | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<string>(validTab);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [toast, setToast] = useState<{ msg: string; isError: boolean } | null>(null);

  useEffect(() => {
    if (requestedTab && SIDEBAR_ITEMS.some((i) => i.id === requestedTab)) {
      setActiveTab(requestedTab);
    }
  }, [requestedTab]);

  const notify = useCallback((msg: string, isError = false) => {
    setToast({ msg, isError });
    setTimeout(() => {
      setToast((prev) => (prev?.msg === msg ? null : prev));
    }, 4500);
  }, []);

  const loadBootstrap = useCallback(async () => {
    try {
      const res = await adminFetch('/api/admin/bootstrap');
      if (res.status === 401) {
        clearAdminToken();
        navigate('/admin/login', { replace: true });
        return;
      }
      if (!res.ok) {
        throw new Error('Failed to load administration workspace.');
      }
      const json = (await res.json()) as AdminBootstrapData;
      setData(json);
    } catch {
      clearAdminToken();
      navigate('/admin/login', { replace: true });
    } finally {
      setLoading(false);
    }
  }, [navigate]);

  useEffect(() => {
    void loadBootstrap();
  }, [loadBootstrap]);

  const handleLogout = async () => {
    await adminFetch('/api/auth/logout', { method: 'POST' });
    clearAdminToken();
    navigate('/admin/login', { replace: true });
  };

  if (loading || !data) {
    return (
      <div className="min-h-screen bg-[#F8F9FB] flex items-center justify-center p-6">
        <p className="text-sm font-medium text-slate-600">Verifying owner permissions...</p>
      </div>
    );
  }

  const activeNavItem = SIDEBAR_ITEMS.find((i) => i.id === activeTab);
  const newSubmissionsCount = data.contactSubmissions.filter((s) => s.status === 'New').length;

  const handleMediaUploaded = (asset: MediaAsset) => {
    setData((prev) => (prev ? { ...prev, mediaLibrary: [asset, ...prev.mediaLibrary] } : prev));
  };

  return (
    <div className="min-h-screen bg-[#F8F9FB] flex">
      {/* Sidebar Desktop */}
      <aside className="hidden lg:flex lg:flex-col w-72 bg-[#0B192C] text-slate-300 shrink-0 border-r border-slate-800">
        <div className="px-6 py-5 border-b border-slate-800">
          <p className="font-display text-lg font-semibold text-white">Edward Duncan</p>
          <p className="text-xs text-[#D9B44A] mt-0.5">Owner Administration</p>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto" aria-label="Admin Navigation">
          {SIDEBAR_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between gap-2 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors text-left ${
                  isActive
                    ? 'bg-[#C59B27] text-[#0B192C] font-semibold'
                    : 'text-slate-300 hover:bg-[#11223B] hover:text-white'
                }`}
              >
                <span className="flex items-center gap-2.5 min-w-0">
                  <Icon className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span className="truncate">{item.label}</span>
                </span>
                {item.id === 'submissions' && newSubmissionsCount > 0 && (
                  <span className="font-mono-tabular text-[11px] font-bold px-1.5 py-0.5 rounded bg-white/20">
                    {newSubmissionsCount}
                  </span>
                )}
              </button>
            );
          })}

          <div className="pt-3 mt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={handleLogout}
              className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-xs font-medium text-red-300 hover:bg-red-950/50 hover:text-red-200 transition-colors"
            >
              <LogOut className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>Logout</span>
            </button>
          </div>
        </nav>
      </aside>

      {/* Mobile Sidebar Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden bg-black/60" onClick={() => setMobileMenuOpen(false)}>
          <aside
            className="w-72 h-full bg-[#0B192C] text-slate-300 flex flex-col overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
              <div>
                <p className="font-display text-lg font-semibold text-white">Edward Duncan</p>
                <p className="text-xs text-[#D9B44A]">Owner Administration</p>
              </div>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 px-3 py-4 space-y-1">
              {SIDEBAR_ITEMS.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setActiveTab(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-xs font-medium text-left ${
                      isActive ? 'bg-[#C59B27] text-[#0B192C] font-semibold' : 'text-slate-300 hover:bg-[#11223B]'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}
              <button
                type="button"
                onClick={handleLogout}
                className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-xs font-medium text-red-300 hover:bg-red-950/50 mt-4"
              >
                <LogOut className="w-4 h-4 shrink-0" />
                <span>Logout</span>
              </button>
            </nav>
          </aside>
        </div>
      )}

      {/* Main Content Workspace */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="bg-white border-b border-slate-200 px-4 sm:px-8 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-2 rounded-lg border border-slate-200 text-slate-700"
              aria-label="Open admin menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="text-sm text-slate-500 truncate">
              <span>Admin</span>
              <span className="mx-2">/</span>
              <span className="font-semibold text-[#0B192C]">
                {activeNavItem?.label || 'Dashboard Overview'}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-4 shrink-0">
            <Link
              to="/"
              target="_blank"
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#0B192C] hover:text-[#8F6A10] whitespace-nowrap"
            >
              <span>View Public Site</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </Link>
            <button
              type="button"
              onClick={handleLogout}
              className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Logout</span>
            </button>
          </div>
        </header>

        {toast && (
          <div
            role="status"
            className={`mx-4 sm:mx-8 mt-4 px-4 py-3 rounded-xl border text-sm font-medium ${
              toast.isError
                ? 'bg-red-50 border-red-200 text-red-900'
                : 'bg-emerald-50 border-emerald-200 text-emerald-900'
            }`}
          >
            {toast.msg}
          </div>
        )}

        <main className="flex-1 p-4 sm:p-8 overflow-y-auto">
          {activeTab === 'overview' && (
            <AdminOverviewPanel
              stats={{
                services: data.services.length,
                portfolio: data.portfolio.length,
                featuredBooks: data.featuredBooks.length,
                authors: data.authors.length,
                testimonials: data.testimonials.length,
                submissions: data.contactSubmissions.length,
                newSubmissions: newSubmissionsCount,
                media: data.mediaLibrary.length,
              }}
              recentSubmissions={data.contactSubmissions}
              onNavigate={setActiveTab}
            />
          )}

          {activeTab === 'services' && (
            <ManageServicesPanel
              services={data.services}
              mediaLibrary={data.mediaLibrary}
              onMediaUploaded={handleMediaUploaded}
              onChange={(services) => {
                setData({ ...data, services });
                void refreshSiteData();
              }}
              onNotify={notify}
            />
          )}

          {activeTab === 'portfolio' && (
            <ManagePortfolioPanel
              portfolio={data.portfolio}
              mediaLibrary={data.mediaLibrary}
              onMediaUploaded={handleMediaUploaded}
              onChange={(portfolio) => {
                setData({ ...data, portfolio });
                void refreshSiteData();
              }}
              onNotify={notify}
            />
          )}

          {activeTab === 'upload-spotlight' && (
            <PromotionalUploadCenterPanel
              key="spotlight"
              mode="spotlight"
              mediaLibrary={data.mediaLibrary}
              onMediaUploaded={handleMediaUploaded}
              onPortfolioCreated={(item) => {
                setData((prev) => (prev ? { ...prev, portfolio: [item, ...prev.portfolio] } : prev));
                void refreshSiteData();
              }}
              onNotify={notify}
            />
          )}

          {activeTab === 'upload-banners' && (
            <PromotionalUploadCenterPanel
              key="banner"
              mode="banner"
              mediaLibrary={data.mediaLibrary}
              onMediaUploaded={handleMediaUploaded}
              onPortfolioCreated={(item) => {
                setData((prev) => (prev ? { ...prev, portfolio: [item, ...prev.portfolio] } : prev));
                void refreshSiteData();
              }}
              onNotify={notify}
            />
          )}

          {activeTab === 'upload-trailers' && (
            <PromotionalUploadCenterPanel
              key="trailer"
              mode="trailer"
              mediaLibrary={data.mediaLibrary}
              onMediaUploaded={handleMediaUploaded}
              onPortfolioCreated={(item) => {
                setData((prev) => (prev ? { ...prev, portfolio: [item, ...prev.portfolio] } : prev));
                void refreshSiteData();
              }}
              onNotify={notify}
            />
          )}

          {activeTab === 'books' && (
            <ManageFeaturedBooksPanel
              books={data.featuredBooks}
              mediaLibrary={data.mediaLibrary}
              onMediaUploaded={handleMediaUploaded}
              onChange={(featuredBooks) => {
                setData({ ...data, featuredBooks });
                void refreshSiteData();
              }}
              onNotify={notify}
            />
          )}

          {activeTab === 'authors' && (
            <ManageAuthorsPanel
              authors={data.authors}
              mediaLibrary={data.mediaLibrary}
              onMediaUploaded={handleMediaUploaded}
              onChange={(authors) => {
                setData({ ...data, authors });
                void refreshSiteData();
              }}
              onNotify={notify}
            />
          )}

          {activeTab === 'testimonials' && (
            <ManageTestimonialsPanel
              testimonials={data.testimonials}
              mediaLibrary={data.mediaLibrary}
              onMediaUploaded={handleMediaUploaded}
              onChange={(testimonials) => {
                setData({ ...data, testimonials });
                void refreshSiteData();
              }}
              onNotify={notify}
            />
          )}

          {activeTab === 'homepage' && (
            <ManageHomepagePanel
              homepage={data.homepage}
              mediaLibrary={data.mediaLibrary}
              onMediaUploaded={handleMediaUploaded}
              onSaved={(homepage) => {
                setData({ ...data, homepage });
                void refreshSiteData();
              }}
              onNotify={notify}
            />
          )}

          {activeTab === 'about' && (
            <ManageAboutPanel
              about={data.about}
              mediaLibrary={data.mediaLibrary}
              onMediaUploaded={handleMediaUploaded}
              onSaved={(about) => {
                setData({ ...data, about });
                void refreshSiteData();
              }}
              onNotify={notify}
            />
          )}

          {activeTab === 'submissions' && (
            <ContactSubmissionsPanel
              submissions={data.contactSubmissions}
              onChange={(contactSubmissions) => setData({ ...data, contactSubmissions })}
              onNotify={notify}
            />
          )}

          {activeTab === 'media' && (
            <MediaLibraryPanel
              mediaLibrary={data.mediaLibrary}
              onUploaded={handleMediaUploaded}
              onDeleted={(id) =>
                setData((prev) =>
                  prev
                    ? { ...prev, mediaLibrary: prev.mediaLibrary.filter((m) => m.id !== id) }
                    : prev,
                )
              }
              onNotify={notify}
            />
          )}

          {activeTab === 'settings' && (
            <WebsiteSettingsPanel
              settings={data.settings}
              pagesCopy={data.pagesCopy}
              onSaved={(settings) => {
                setData((prev) => (prev ? { ...prev, settings } : prev));
                void refreshSiteData();
              }}
              onPagesCopySaved={(pagesCopy) => {
                setData((prev) => (prev ? { ...prev, pagesCopy } : prev));
                void refreshSiteData();
              }}
              onNotify={notify}
            />
          )}

          {activeTab === 'security' && (
            <SecuritySettingsPanel
              owner={data.owner}
              sessions={data.sessions}
              onRefresh={loadBootstrap}
              onNotify={notify}
            />
          )}
        </main>
      </div>
    </div>
  );
}
