import { AlertCircle, ArrowLeft, CheckCircle2, KeyRound } from 'lucide-react';
import React, { useState } from 'react';
import { Link } from 'react-router-dom';

export function AdminResetPasswordPage() {
  const [email, setEmail] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [requestLoading, setRequestLoading] = useState(false);
  const [requestMsg, setRequestMsg] = useState<string | null>(null);
  const [resetLoading, setResetLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleRequestCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setRequestMsg(null);
    if (!email.trim()) {
      setErrorMsg('Enter your authorized owner email address first.');
      return;
    }
    setRequestLoading(true);
    try {
      const res = await fetch('/api/auth/request-reset', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim() }),
      });
      const data = await res.json();
      setRequestMsg(data.message || 'Reset request processed.');
    } catch {
      setErrorMsg('Unable to request reset code.');
    } finally {
      setRequestLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!email.trim() || !verificationCode.trim() || !newPassword) {
      setErrorMsg('Please complete all fields.');
      return;
    }
    if (newPassword.length < 8) {
      setErrorMsg('New password must be at least 8 characters long.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setErrorMsg('Passwords do not match.');
      return;
    }

    setResetLoading(true);
    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: email.trim(),
          verificationCode: verificationCode.trim(),
          newPassword,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Password reset failed.');
      }
      setSuccessMsg(data.message);
      setVerificationCode('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Password reset failed.');
    } finally {
      setResetLoading(false);
    }
  };

  return (
    <div className="bg-[#06101E] flex flex-col justify-center py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full mx-auto space-y-8">
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-[#11223B] border border-slate-700 text-[#D9B44A] mb-2">
            <KeyRound className="w-5 h-5" aria-hidden="true" />
          </div>
          <h1 className="font-display text-3xl font-semibold text-white">
            Owner Password Reset
          </h1>
          <p className="text-sm text-slate-400">
            Verify via timed reset code or your saved Owner Recovery Key
          </p>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-xl space-y-6">
          {errorMsg && (
            <div
              role="alert"
              className="flex items-start gap-2.5 p-3.5 rounded-lg border border-red-200 bg-red-50 text-red-900 text-sm"
            >
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {requestMsg && (
            <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 text-xs leading-relaxed">
              {requestMsg}
            </div>
          )}

          {successMsg && (
            <div className="flex items-start gap-2.5 p-4 rounded-lg border border-emerald-200 bg-emerald-50 text-emerald-900 text-sm">
              <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
              <div className="space-y-2">
                <p>{successMsg}</p>
                <Link
                  to="/admin/login"
                  className="inline-block font-semibold text-[#0B192C] underline"
                >
                  Proceed to Owner Sign In
                </Link>
              </div>
            </div>
          )}

          <form onSubmit={handleResetPassword} className="space-y-4">
            <div>
              <label htmlFor="reset-email" className="block text-sm font-medium text-slate-800 mb-1.5">
                Owner Email Address
              </label>
              <div className="flex gap-2">
                <input
                  id="reset-email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="edwardduncan.info@gmail.com"
                  className="flex-1 px-3.5 py-2.5 rounded-lg border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#C59B27]"
                />
                <button
                  type="button"
                  onClick={handleRequestCode}
                  disabled={requestLoading}
                  className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-slate-50 text-xs font-semibold text-[#0B192C] hover:bg-slate-100 whitespace-nowrap shrink-0"
                >
                  {requestLoading ? 'Sending...' : 'Request Code'}
                </button>
              </div>
            </div>

            <div>
              <label htmlFor="reset-code" className="block text-sm font-medium text-slate-800 mb-1.5">
                Reset Code or Owner Recovery Key
              </label>
              <input
                id="reset-code"
                type="text"
                required
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value)}
                placeholder="XXXX-XXXX or EDBP-..."
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-sm font-mono text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#C59B27]"
              />
            </div>

            <div>
              <label htmlFor="new-pw" className="block text-sm font-medium text-slate-800 mb-1.5">
                New Password (min. 8 characters)
              </label>
              <input
                id="new-pw"
                type="password"
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#C59B27]"
              />
            </div>

            <div>
              <label htmlFor="confirm-pw" className="block text-sm font-medium text-slate-800 mb-1.5">
                Confirm New Password
              </label>
              <input
                id="confirm-pw"
                type="password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#C59B27]"
              />
            </div>

            <button
              type="submit"
              disabled={resetLoading}
              className="w-full py-3 rounded-lg bg-[#0B192C] text-white text-sm font-semibold hover:bg-[#132945] disabled:opacity-60 transition-colors"
            >
              {resetLoading ? 'Updating Password...' : 'Reset Owner Password'}
            </button>
          </form>
        </div>

        <div className="text-center">
          <Link
            to="/admin/login"
            className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-400 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Owner Sign In</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
