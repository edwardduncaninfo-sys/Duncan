import { AlertCircle, CheckCircle2, Mail, MapPin, Upload, X } from 'lucide-react';
import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useSiteData } from '../context/SiteDataContext';

export function ContactPage() {
  const { siteData } = useSiteData();
  const [searchParams] = useSearchParams();
  const initialService = searchParams.get('service') || '';

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [bookTitle, setBookTitle] = useState('');
  const [bookGenre, setBookGenre] = useState('');
  const [authorWebsite, setAuthorWebsite] = useState('');
  const [requestedService, setRequestedService] = useState(initialService);
  const [message, setMessage] = useState('');
  const [bookCoverFile, setBookCoverFile] = useState<File | null>(null);

  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const serviceOptions = siteData?.services.map((s) => s.title) || [
    'Amazon Optimization',
    'Amazon A+ Content',
    'Goodreads Profile Optimization',
    "Author's Website Development",
    'Book Trailer & UGC Book Video',
    'Author Newsletter & Book Content',
    'Goodreads Listopia Placement',
    'Goodreads Review Campaigns',
  ];

  useEffect(() => {
    if (initialService) {
      setRequestedService(initialService);
    } else if (!requestedService && serviceOptions.length > 0) {
      setRequestedService(serviceOptions[0]);
    }
  }, [initialService, serviceOptions.length]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!fullName.trim() || !email.trim() || !bookTitle.trim() || !requestedService.trim() || !message.trim()) {
      setErrorMsg('Please complete all required fields marked with an asterisk.');
      return;
    }

    setSubmitting(true);
    try {
      const formData = new FormData();
      formData.append('fullName', fullName.trim());
      formData.append('email', email.trim());
      formData.append('bookTitle', bookTitle.trim());
      formData.append('bookGenre', bookGenre.trim());
      formData.append('authorWebsite', authorWebsite.trim());
      formData.append('requestedService', requestedService.trim());
      formData.append('message', message.trim());
      if (bookCoverFile) {
        formData.append('bookCover', bookCoverFile);
      }

      const res = await fetch('/api/contact', {
        method: 'POST',
        body: formData,
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Unable to submit your request.');
      }

      setSuccessMsg(
        data.message || 'Your book promotion request has been securely submitted.',
      );
      setFullName('');
      setEmail('');
      setBookTitle('');
      setBookGenre('');
      setAuthorWebsite('');
      setMessage('');
      setBookCoverFile(null);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Submission failed. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const settings = siteData?.settings;
  const pagesCopy = siteData?.pagesCopy;
  const socialLinks = settings?.socialLinks;
  const activeSocials = [
    { label: 'LinkedIn', url: socialLinks?.linkedin },
    { label: 'Instagram', url: socialLinks?.instagram },
    { label: 'X (Twitter)', url: socialLinks?.x },
    { label: 'Facebook', url: socialLinks?.facebook },
    { label: 'YouTube', url: socialLinks?.youtube },
  ].filter((s) => Boolean(s.url));

  return (
    <div>
      <section className="bg-[#0B192C] text-white py-20 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            <p className="text-xs font-semibold tracking-wide text-[#D9B44A]">
              {pagesCopy?.contactKicker || 'Book Promotion Inquiry'}
            </p>
            <h1
              className="font-display font-semibold tracking-tight text-white text-balance leading-tight"
              style={{ fontSize: 'clamp(2rem, 3.8vw, 3.25rem)' }}
            >
              {pagesCopy?.contactHeading || 'Request a Tailored Promotion Quote'}
            </h1>
            <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
              {pagesCopy?.contactSubheading ||
                'Tell us about your book, publishing timeline, and promotional goals. All inquiries are reviewed directly by Edward Duncan.'}
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            {/* Contact Form */}
            <div className="lg:col-span-8">
              <div className="border border-slate-200 rounded-2xl p-6 sm:p-10 bg-white">
                <h2 className="font-display text-2xl font-semibold text-[#0B192C] mb-6">
                  {pagesCopy?.contactFormHeading || 'Book Promotion Request Form'}
                </h2>

                {errorMsg && (
                  <div
                    role="alert"
                    className="mb-6 flex items-start gap-3 p-4 rounded-xl border border-red-200 bg-red-50 text-red-900 text-sm"
                  >
                    <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" aria-hidden="true" />
                    <p>{errorMsg}</p>
                  </div>
                )}

                {successMsg && (
                  <div
                    role="status"
                    className="mb-6 flex items-start gap-3 p-4 rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-900 text-sm"
                  >
                    <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" aria-hidden="true" />
                    <div>
                      <p className="font-semibold">{pagesCopy?.contactSuccessTitle || 'Inquiry Received'}</p>
                      <p className="mt-1">{successMsg}</p>
                    </div>
                  </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-6" noValidate>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="fullName" className="block text-sm font-medium text-slate-800 mb-1.5">
                        {pagesCopy?.contactNameLabel || 'Full Name'} <span className="text-red-600">*</span>
                      </label>
                      <input
                        id="fullName"
                        type="text"
                        required
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        placeholder="Your full name"
                        className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#C59B27] focus:border-transparent"
                      />
                    </div>

                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-slate-800 mb-1.5">
                        {pagesCopy?.contactEmailLabel || 'Email Address'} <span className="text-red-600">*</span>
                      </label>
                      <input
                        id="email"
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="author@example.com"
                        className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#C59B27] focus:border-transparent"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="bookTitle" className="block text-sm font-medium text-slate-800 mb-1.5">
                        {pagesCopy?.contactBookTitleLabel || 'Book Title'} <span className="text-red-600">*</span>
                      </label>
                      <input
                        id="bookTitle"
                        type="text"
                        required
                        value={bookTitle}
                        onChange={(e) => setBookTitle(e.target.value)}
                        placeholder="Title of your book"
                        className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#C59B27] focus:border-transparent"
                      />
                    </div>

                    <div>
                      <label htmlFor="bookGenre" className="block text-sm font-medium text-slate-800 mb-1.5">
                        {pagesCopy?.contactGenreLabel || 'Book Genre'}
                      </label>
                      <input
                        id="bookGenre"
                        type="text"
                        value={bookGenre}
                        onChange={(e) => setBookGenre(e.target.value)}
                        placeholder="e.g., Historical Fiction, Thriller, Memoir"
                        className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#C59B27] focus:border-transparent"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="authorWebsite" className="block text-sm font-medium text-slate-800 mb-1.5">
                        {pagesCopy?.contactWebsiteLabel || 'Author Website (Optional)'}
                      </label>
                      <input
                        id="authorWebsite"
                        type="url"
                        value={authorWebsite}
                        onChange={(e) => setAuthorWebsite(e.target.value)}
                        placeholder="https://yourwebsite.com"
                        className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#C59B27] focus:border-transparent"
                      />
                    </div>

                    <div>
                      <label htmlFor="requestedService" className="block text-sm font-medium text-slate-800 mb-1.5">
                        {pagesCopy?.contactServiceLabel || 'Requested Service'} <span className="text-red-600">*</span>
                      </label>
                      <select
                        id="requestedService"
                        required
                        value={requestedService}
                        onChange={(e) => setRequestedService(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#C59B27] focus:border-transparent"
                      >
                        {serviceOptions.map((opt) => (
                          <option key={opt} value={opt}>
                            {opt}
                          </option>
                        ))}
                        {initialService && !serviceOptions.includes(initialService) && (
                          <option value={initialService}>{initialService}</option>
                        )}
                        <option value={pagesCopy?.contactExtraServiceOption || 'Full Campaign Consultation'}>
                          {pagesCopy?.contactExtraServiceOption || 'Full Campaign Consultation'}
                        </option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-slate-800 mb-1.5">
                      {pagesCopy?.contactMessageLabel || 'Message & Campaign Goals'} <span className="text-red-600">*</span>
                    </label>
                    <textarea
                      id="message"
                      rows={5}
                      required
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Share a brief synopsis, publication status (upcoming launch or already published), and what you would like to achieve..."
                      className="w-full px-4 py-3 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#C59B27] focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-800 mb-1.5">
                      {pagesCopy?.contactUploadLabel || 'Optional Book Cover Upload (JPG, PNG, WebP · Max 10MB)'}
                    </label>
                    <div className="flex flex-wrap items-center gap-4 p-4 rounded-xl border border-dashed border-slate-300 bg-[#F8F9FB]">
                      <label className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-white border border-slate-300 text-xs font-semibold text-[#0B192C] hover:bg-slate-50 cursor-pointer">
                        <Upload className="w-4 h-4 text-[#8F6A10]" aria-hidden="true" />
                        <span>{bookCoverFile ? 'Change Cover Image' : 'Choose Cover Image'}</span>
                        <input
                          type="file"
                          accept="image/jpeg,image/png,image/webp,image/gif"
                          className="sr-only"
                          onChange={(e) => setBookCoverFile(e.target.files?.[0] || null)}
                        />
                      </label>
                      {bookCoverFile ? (
                        <div className="flex items-center gap-2 text-xs text-slate-700">
                          <span className="font-medium truncate max-w-[220px]">{bookCoverFile.name}</span>
                          <button
                            type="button"
                            onClick={() => setBookCoverFile(null)}
                            aria-label="Remove selected cover"
                            className="p-1 rounded hover:bg-slate-200 text-slate-500"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <span className="text-xs text-slate-500">
                          {pagesCopy?.contactUploadHint || 'Attach your current cover artwork for visual review if available.'}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      disabled={submitting}
                      className="w-full sm:w-auto px-8 py-3.5 rounded-lg bg-[#0B192C] text-white text-sm font-semibold hover:bg-[#132945] disabled:opacity-60 transition-colors"
                    >
                      {submitting ? 'Submitting Request...' : (pagesCopy?.contactSubmitLabel || 'Submit Promotion Request')}
                    </button>
                  </div>
                </form>
              </div>
            </div>

            {/* Agency Details Sidebar */}
            <aside className="lg:col-span-4 space-y-6">
              <div className="bg-[#0B192C] text-white rounded-2xl p-8 space-y-6">
                <div className="space-y-2">
                  <p className="text-xs font-semibold tracking-wide text-[#D9B44A]">
                    {pagesCopy?.contactSidebarKicker || 'Direct Agency Contact'}
                  </p>
                  <h3 className="font-display text-2xl font-semibold text-white">
                    {settings?.businessName || 'Edward Duncan Book Promotions'}
                  </h3>
                  <p className="text-sm text-slate-300 leading-relaxed">
                    {settings?.businessDescription}
                  </p>
                </div>

                <div className="space-y-4 pt-4 border-t border-slate-700/70 text-sm">
                  <div className="flex items-start gap-3">
                    <Mail className="w-4 h-4 text-[#D9B44A] shrink-0 mt-1" aria-hidden="true" />
                    <div>
                      <p className="text-xs text-slate-400">
                        {pagesCopy?.contactSidebarEmailLabel || 'Business Email'}
                      </p>
                      <a
                        href={`mailto:${settings?.contactEmail || 'edwardduncan.info@gmail.com'}`}
                        className="font-medium text-white hover:text-[#D9B44A] transition-colors"
                      >
                        {settings?.contactEmail || 'edwardduncan.info@gmail.com'}
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <MapPin className="w-4 h-4 text-[#D9B44A] shrink-0 mt-1" aria-hidden="true" />
                    <div>
                      <p className="text-xs text-slate-400">
                        {pagesCopy?.contactSidebarLocationLabel || 'Availability'}
                      </p>
                      <p className="text-white">
                        {settings?.location || 'Serving Authors & Publishers Worldwide'}
                      </p>
                    </div>
                  </div>
                </div>

                {activeSocials.length > 0 && (
                  <div className="pt-4 border-t border-slate-700/70 space-y-2.5">
                    <p className="text-xs font-semibold tracking-wide text-slate-400">
                      {pagesCopy?.contactSidebarChannelsLabel || 'Agency Channels'}
                    </p>
                    <div className="flex flex-wrap gap-3">
                      {activeSocials.map((s) => (
                        <a
                          key={s.label}
                          href={s.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs font-medium text-[#D9B44A] hover:text-white underline underline-offset-4"
                        >
                          {s.label}
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </aside>
          </div>
        </div>
      </section>
    </div>
  );
}
