import { ArrowRight, ExternalLink, Play, Star, X } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ResilientImage } from '../components/ResilientImage';
import { VideoPreviewPlayer } from '../components/VideoPreviewPlayer';
import { useSiteData } from '../context/SiteDataContext';
import type { PortfolioItem } from '../types/cms';

export function HomePage() {
  const { siteData, loading } = useSiteData();
  const [selectedPortfolio, setSelectedPortfolio] = useState<PortfolioItem | null>(null);

  if (loading && !siteData) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 space-y-8 animate-pulse">
        <div className="h-96 rounded-2xl bg-slate-100" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="h-56 rounded-xl bg-slate-100" />
          <div className="h-56 rounded-xl bg-slate-100" />
          <div className="h-56 rounded-xl bg-slate-100" />
        </div>
      </div>
    );
  }

  if (!siteData) return null;

  const { homepage, services, portfolio, featuredBooks, testimonials, settings, pagesCopy } = siteData;
  const featuredServices = services.filter((s) => s.featuredOnHome);
  const showcasePortfolio =
    portfolio.filter((p) => p.featuredOnHome).length > 0
      ? portfolio.filter((p) => p.featuredOnHome)
      : portfolio.slice(0, 3);
  const homeBooks =
    featuredBooks.filter((b) => b.featuredOnHome).length > 0
      ? featuredBooks.filter((b) => b.featuredOnHome)
      : featuredBooks.slice(0, 3);

  return (
    <div>
      {/* 1. HERO SECTION */}
      <section className="relative bg-[#0B192C] text-white overflow-hidden">
        <div className="absolute inset-0">
          <ResilientImage
            src={homepage.heroImageUrl}
            alt="Curated literary hardcover editions on library desk"
            className="w-full h-full object-cover opacity-55"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#06101E]/95 via-[#0B192C]/85 to-[#0B192C]/55" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
          <div className="max-w-3xl space-y-6">
            <p className="text-sm font-medium tracking-wide text-[#D9B44A]">
              {homepage.heroKicker || `${settings.businessName} · ${settings.specialistTitle}`}
            </p>
            <h1
              className="font-display font-semibold tracking-tight text-white leading-[1.1] text-balance"
              style={{ fontSize: 'clamp(2.25rem, 4.2vw, 3.75rem)' }}
            >
              {homepage.heroHeadline}
            </h1>
            <p className="text-base sm:text-lg text-slate-200 leading-relaxed max-w-2xl">
              {homepage.heroSubheadline}
            </p>
            <div className="pt-3 flex flex-wrap items-center gap-4">
              <Link
                to="/services"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-lg bg-[#C59B27] text-[#0B192C] text-sm font-semibold hover:bg-[#D9B44A] transition-colors duration-150 whitespace-nowrap shrink-0"
              >
                <span>{homepage.primaryCtaLabel}</span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </Link>
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-lg border border-white/35 bg-white/5 text-white text-sm font-semibold hover:bg-white/15 transition-colors duration-150 whitespace-nowrap shrink-0"
              >
                <span>{homepage.secondaryCtaLabel}</span>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* 2. VISUAL SHOWCASE: BOOK COVERS, BANNERS & BOOK TRAILERS */}
      <section className="py-20 bg-[#F8F9FB] border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
            <div className="max-w-2xl space-y-3">
              <p className="text-xs font-semibold tracking-wide text-[#8F6A10]">
                {homepage.showcaseKicker}
              </p>
              <h2 className="font-display text-3xl sm:text-4xl font-semibold text-[#0B192C] tracking-tight text-balance">
                {homepage.showcaseHeading}
              </h2>
              <p className="text-slate-600 leading-relaxed">{homepage.showcaseSubheading}</p>
            </div>
            <Link
              to="/portfolio"
              className="inline-flex items-center gap-2 text-sm font-semibold text-[#0B192C] hover:text-[#8F6A10] transition-colors whitespace-nowrap shrink-0"
            >
              <span>{homepage.showcaseCtaLabel}</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </Link>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {showcasePortfolio.map((item, idx) => {
              const isLead = idx === 0;
              return (
                <article
                  key={item.id}
                  className={`${
                    isLead ? 'lg:col-span-7' : 'lg:col-span-5'
                  } group bg-white rounded-xl border border-slate-200 overflow-hidden flex flex-col`}
                >
                  <button
                    type="button"
                    onClick={() => setSelectedPortfolio(item)}
                    className="relative w-full aspect-[16/10] overflow-hidden bg-slate-900 text-left focus-visible:outline-2 focus-visible:outline-[#C59B27]"
                  >
                    <ResilientImage
                      src={item.bannerImageUrl || item.bookCoverUrl}
                      alt={`${item.projectTitle} promotional preview`}
                      fallbackTitle={item.bookTitle || item.projectTitle}
                      className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-300"
                    />
                    {item.videoUrl && (
                      <span className="absolute bottom-3 right-3 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#0B192C]/90 text-white text-xs font-medium">
                        <Play className="w-3.5 h-3.5 text-[#D9B44A]" aria-hidden="true" />
                        <span>{pagesCopy.videoPreviewLabel}</span>
                      </span>
                    )}
                  </button>
                  <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                    <div className="space-y-2">
                      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                        <span className="font-medium text-[#8F6A10]">{item.category}</span>
                        <span aria-hidden="true">·</span>
                        <span>{item.bookTitle}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono-tabular">{item.publicationDate}</span>
                      </div>
                      <h3 className="font-display text-xl font-semibold text-[#0B192C]">
                        {item.projectTitle}
                      </h3>
                      <p className="text-sm text-slate-600 leading-relaxed line-clamp-2">
                        {item.description}
                      </p>
                    </div>
                    <div className="pt-2 flex items-center justify-between border-t border-slate-100">
                      <span className="text-xs text-slate-500">{item.authorName}</span>
                      <button
                        type="button"
                        onClick={() => setSelectedPortfolio(item)}
                        className="text-xs font-semibold text-[#0B192C] hover:text-[#8F6A10] transition-colors"
                      >
                        {pagesCopy.inspectCampaignLabel}
                      </button>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      {/* 3. SHORT INTRODUCTION TO EDWARD DUNCAN */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
            <div className="lg:col-span-5">
              <div className="h-full min-h-[380px] rounded-xl overflow-hidden border border-slate-200 bg-slate-100">
                <ResilientImage
                  src={homepage.introPortraitUrl}
                  alt={`${settings.specialistName}, ${settings.specialistTitle}`}
                  fallbackTitle={settings.specialistName}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            <div className="lg:col-span-7 flex flex-col justify-center space-y-6">
              <div className="space-y-3">
                <p className="text-xs font-semibold tracking-wide text-[#8F6A10]">
                  {homepage.introKicker}
                </p>
                <h2 className="font-display text-3xl sm:text-4xl font-semibold text-[#0B192C] tracking-tight text-balance">
                  {homepage.introHeading}
                </h2>
              </div>
              <p className="text-base text-slate-600 leading-relaxed">{homepage.introBody}</p>
              {homepage.introPillars && homepage.introPillars.length > 0 && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-4 border-t border-slate-200">
                  {homepage.introPillars.map((pillar, pIdx) => (
                    <div key={pIdx}>
                      <p className="font-display text-lg font-semibold text-[#0B192C]">{pillar.title}</p>
                      <p className="text-xs text-slate-500 mt-1">{pillar.subtitle}</p>
                    </div>
                  ))}
                </div>
              )}
              <div className="pt-2">
                <Link
                  to="/about"
                  className="inline-flex items-center gap-2 px-5 py-3 rounded-lg bg-[#0B192C] text-white text-sm font-semibold hover:bg-[#132945] transition-colors"
                >
                  <span>{homepage.introCtaLabel || `Read About ${settings.specialistName}`}</span>
                  <ArrowRight className="w-4 h-4" aria-hidden="true" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. FEATURED PROMOTIONAL SERVICES */}
      <section className="py-20 bg-[#0B192C] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
            <div className="max-w-2xl space-y-3">
              <p className="text-xs font-semibold tracking-wide text-[#D9B44A]">
                {homepage.servicesKicker}
              </p>
              <h2 className="font-display text-3xl sm:text-4xl font-semibold text-white tracking-tight text-balance">
                {homepage.servicesHeading}
              </h2>
              <p className="text-slate-300 leading-relaxed">{homepage.servicesSubheading}</p>
            </div>
            <Link
              to="/services"
              className="inline-flex items-center gap-2 text-sm font-semibold text-[#D9B44A] hover:text-white transition-colors whitespace-nowrap shrink-0"
            >
              <span>{homepage.servicesCtaLabel}</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </Link>
          </div>

          <div
            className={`grid grid-cols-1 md:grid-cols-2 gap-6 ${
              featuredServices.length === 4 || featuredServices.length === 8
                ? 'lg:grid-cols-4'
                : 'lg:grid-cols-3'
            }`}
          >
            {featuredServices.map((svc, idx) => (
              <div
                key={svc.id}
                className="bg-[#11223B] border border-slate-700/70 rounded-xl p-6 flex flex-col justify-between space-y-5"
              >
                <div className="space-y-3">
                  <div className="text-xs font-mono-tabular text-[#D9B44A]">
                    {String(idx + 1).padStart(2, '0')}.
                  </div>
                  <h3 className="font-display text-xl font-semibold text-white">{svc.title}</h3>
                  <p className="text-sm text-slate-300 leading-relaxed">{svc.shortDescription}</p>
                </div>
                <div className="pt-4 border-t border-slate-700/60 flex items-center justify-between">
                  <Link
                    to={`/contact?service=${encodeURIComponent(svc.title)}`}
                    className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#D9B44A] hover:text-white transition-colors"
                  >
                    <span>{pagesCopy.requestServiceLabel}</span>
                    <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. SELECTED AUTHOR SUCCESS & FEATURED BOOKS */}
      <section className="py-20 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
            <div className="max-w-2xl space-y-3">
              <p className="text-xs font-semibold tracking-wide text-[#8F6A10]">
                {homepage.successStoriesKicker}
              </p>
              <h2 className="font-display text-3xl sm:text-4xl font-semibold text-[#0B192C] tracking-tight text-balance">
                {homepage.successStoriesHeading}
              </h2>
              <p className="text-slate-600 leading-relaxed">{homepage.successStoriesSubheading}</p>
            </div>
            <Link
              to="/books"
              className="inline-flex items-center gap-2 text-sm font-semibold text-[#0B192C] hover:text-[#8F6A10] transition-colors whitespace-nowrap shrink-0"
            >
              <span>{homepage.successStoriesCtaLabel}</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {homeBooks.map((book) => (
              <article
                key={book.id}
                className="bg-white border border-slate-200 rounded-xl overflow-hidden flex flex-col justify-between"
              >
                <div className="aspect-[4/3] bg-slate-100 overflow-hidden">
                  <ResilientImage
                    src={book.bookCoverUrl}
                    alt={`${book.bookTitle} by ${book.authorName}`}
                    fallbackTitle={book.bookTitle}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <p className="text-xs text-slate-500">
                      <span className="font-medium text-[#8F6A10]">{book.genre}</span>
                      <span aria-hidden="true"> · </span>
                      <span>{book.authorName}</span>
                    </p>
                    <h3 className="font-display text-xl font-semibold text-[#0B192C]">
                      {book.bookTitle}
                    </h3>
                    <p className="text-sm text-slate-600 leading-relaxed line-clamp-3">
                      {book.shortDescription}
                    </p>
                  </div>
                  <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-3">
                    <Link
                      to={`/books/${book.id}`}
                      className="text-sm font-semibold text-[#0B192C] hover:text-[#8F6A10] transition-colors"
                    >
                      {pagesCopy.viewFeatureLabel}
                    </Link>
                    {book.purchaseLink && (
                      <a
                        href={book.purchaseLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-xs font-medium text-slate-500 hover:text-[#0B192C]"
                      >
                        <span>{pagesCopy.bookLinkLabel}</span>
                        <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
                      </a>
                    )}
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* 6. AUTHORS' TESTIMONIALS */}
      <section className="py-20 bg-[#F8F9FB]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl space-y-3 mb-12">
            <p className="text-xs font-semibold tracking-wide text-[#8F6A10]">
              {homepage.testimonialsKicker}
            </p>
            <h2 className="font-display text-3xl sm:text-4xl font-semibold text-[#0B192C] tracking-tight text-balance">
              {homepage.testimonialsHeading}
            </h2>
            <p className="text-slate-600 leading-relaxed">{homepage.testimonialsSubheading}</p>
          </div>

          {testimonials.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-xl p-8 text-center">
              <p className="text-sm text-slate-600">
                {pagesCopy.emptyTestimonialsText}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {testimonials.map((t) => (
                <article
                  key={t.id}
                  className="bg-white border border-slate-200 rounded-xl p-8 flex flex-col justify-between space-y-6"
                >
                  <div className="space-y-4">
                    {t.isPlaceholder && (
                      <p className="text-xs font-medium text-[#8F6A10]">
                        Identified Placeholder · Awaiting Genuine Author Feedback
                      </p>
                    )}
                    {typeof t.rating === 'number' && t.rating > 0 && (
                      <div className="flex items-center gap-1" aria-label={`Rated ${t.rating} out of 5`}>
                        {Array.from({ length: Math.min(5, t.rating) }).map((_, i) => (
                          <Star
                            key={i}
                            className="w-4 h-4 text-[#C59B27] fill-[#C59B27]"
                            aria-hidden="true"
                          />
                        ))}
                      </div>
                    )}
                    <blockquote className="text-base text-slate-700 leading-relaxed">
                      “{t.testimonialText}”
                    </blockquote>
                  </div>

                  <div className="pt-5 border-t border-slate-100 flex items-center gap-4">
                    <div className="w-12 h-12 rounded-lg overflow-hidden bg-slate-100 shrink-0 border border-slate-200">
                      <ResilientImage
                        src={t.authorPhotoUrl || t.bookCoverUrl}
                        alt={t.authorName}
                        fallbackTitle={t.authorName}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-[#0B192C] truncate">{t.authorName}</p>
                      <p className="text-xs text-slate-500 truncate">
                        {t.bookTitle}
                        {t.authorLink && (
                          <>
                            <span aria-hidden="true"> · </span>
                            <a
                              href={t.authorLink}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-[#8F6A10] hover:underline"
                            >
                              {pagesCopy.authorWebsiteLabel}
                            </a>
                          </>
                        )}
                      </p>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* 7. STRONG CALL-TO-ACTION */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-[#0B192C] rounded-2xl px-8 py-14 sm:px-14 sm:py-16 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8">
            <div className="max-w-2xl space-y-3">
              <p className="text-xs font-semibold tracking-wide text-[#D9B44A]">
                {homepage.ctaKicker}
              </p>
              <h2 className="font-display text-3xl sm:text-4xl font-semibold text-white tracking-tight text-balance">
                {homepage.ctaHeading}
              </h2>
              <p className="text-slate-300 leading-relaxed">{homepage.ctaBody}</p>
            </div>
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 px-7 py-4 rounded-lg bg-[#C59B27] text-[#0B192C] text-sm font-semibold hover:bg-[#D9B44A] transition-colors whitespace-nowrap shrink-0"
            >
              <span>{homepage.ctaButtonLabel}</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </Link>
          </div>
        </div>
      </section>

      {/* PORTFOLIO LIGHTBOX MODAL */}
      {selectedPortfolio && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={selectedPortfolio.projectTitle}
          className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
          onClick={() => setSelectedPortfolio(null)}
        >
          <div
            className="bg-white rounded-2xl max-w-4xl w-full overflow-hidden border border-slate-200 shadow-2xl my-8"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
              <div>
                <p className="text-xs text-[#8F6A10] font-medium">
                  {selectedPortfolio.category} · {selectedPortfolio.publicationDate}
                </p>
                <h3 className="font-display text-xl font-semibold text-[#0B192C]">
                  {selectedPortfolio.projectTitle}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedPortfolio(null)}
                aria-label="Close modal"
                className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-900"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
              {selectedPortfolio.videoUrl ? (
                <VideoPreviewPlayer
                  videoUrl={selectedPortfolio.videoUrl}
                  posterUrl={selectedPortfolio.bannerImageUrl || selectedPortfolio.bookCoverUrl}
                  title={selectedPortfolio.projectTitle}
                />
              ) : (
                <div className="rounded-xl overflow-hidden border border-slate-200 aspect-[16/9] bg-slate-100">
                  <ResilientImage
                    src={selectedPortfolio.bannerImageUrl || selectedPortfolio.bookCoverUrl}
                    alt={selectedPortfolio.projectTitle}
                    className="w-full h-full object-cover"
                  />
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
                {selectedPortfolio.bookCoverUrl && (
                  <div className="md:col-span-4 rounded-xl overflow-hidden border border-slate-200 aspect-[3/4]">
                    <ResilientImage
                      src={selectedPortfolio.bookCoverUrl}
                      alt={selectedPortfolio.bookTitle}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                <div className={selectedPortfolio.bookCoverUrl ? 'md:col-span-8 space-y-3' : 'md:col-span-12 space-y-3'}>
                  <p className="text-sm text-slate-500">
                    Book: <strong className="text-[#0B192C]">{selectedPortfolio.bookTitle}</strong>
                    {selectedPortfolio.authorName ? ` · Author: ${selectedPortfolio.authorName}` : ''}
                  </p>
                  <p className="text-slate-700 leading-relaxed">{selectedPortfolio.description}</p>
                  <div className="pt-3">
                    <Link
                      to={`/contact?service=${encodeURIComponent(selectedPortfolio.category)}`}
                      className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#0B192C] text-white text-sm font-semibold hover:bg-[#132945]"
                    >
                      <span>{pagesCopy.modalRequestCampaignLabel}</span>
                      <ArrowRight className="w-4 h-4" />
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
